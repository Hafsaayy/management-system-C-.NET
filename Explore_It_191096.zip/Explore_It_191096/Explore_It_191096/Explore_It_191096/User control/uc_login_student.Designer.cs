﻿
namespace Explore_It_191096.User_control
{
    partial class uc_login_student
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.uc_student_login = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bt_student_login = new Guna.UI2.WinForms.Guna2Button();
            this.Student_password_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Student_username_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bt_stu_login = new Guna.UI2.WinForms.Guna2Button();
            this.stu_password_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Stu_username_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.SuspendLayout();
            // 
            // uc_student_login
            // 
            this.uc_student_login.TargetControl = this;
            // 
            // guna2HtmlLabel2
            // 
            this.guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel2.Location = new System.Drawing.Point(305, 133);
            this.guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            this.guna2HtmlLabel2.Size = new System.Drawing.Size(103, 22);
            this.guna2HtmlLabel2.TabIndex = 29;
            this.guna2HtmlLabel2.Text = "Student Login";
            this.guna2HtmlLabel2.Click += new System.EventHandler(this.guna2HtmlLabel2_Click);
            // 
            // bt_student_login
            // 
            this.bt_student_login.BorderRadius = 20;
            this.bt_student_login.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            this.bt_student_login.CheckedState.Parent = this.bt_student_login;
            this.bt_student_login.CustomImages.Parent = this.bt_student_login;
            this.bt_student_login.FillColor = System.Drawing.Color.Fuchsia;
            this.bt_student_login.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_student_login.ForeColor = System.Drawing.Color.Black;
            this.bt_student_login.HoverState.Parent = this.bt_student_login;
            this.bt_student_login.Location = new System.Drawing.Point(277, 329);
            this.bt_student_login.Name = "bt_student_login";
            this.bt_student_login.ShadowDecoration.Parent = this.bt_student_login;
            this.bt_student_login.Size = new System.Drawing.Size(180, 45);
            this.bt_student_login.TabIndex = 28;
            this.bt_student_login.Text = "LOGIN";
            this.bt_student_login.Click += new System.EventHandler(this.bt_student_login_Click);
            // 
            // Student_password_textbox
            // 
            this.Student_password_textbox.BorderRadius = 10;
            this.Student_password_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Student_password_textbox.DefaultText = "";
            this.Student_password_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Student_password_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Student_password_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Student_password_textbox.DisabledState.Parent = this.Student_password_textbox;
            this.Student_password_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Student_password_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Student_password_textbox.FocusedState.Parent = this.Student_password_textbox;
            this.Student_password_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Student_password_textbox.HoverState.Parent = this.Student_password_textbox;
            this.Student_password_textbox.Location = new System.Drawing.Point(230, 248);
            this.Student_password_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Student_password_textbox.Name = "Student_password_textbox";
            this.Student_password_textbox.PasswordChar = '\0';
            this.Student_password_textbox.PlaceholderText = "**********";
            this.Student_password_textbox.SelectedText = "";
            this.Student_password_textbox.ShadowDecoration.Parent = this.Student_password_textbox;
            this.Student_password_textbox.Size = new System.Drawing.Size(278, 47);
            this.Student_password_textbox.TabIndex = 27;
            this.Student_password_textbox.TextChanged += new System.EventHandler(this.Student_password_textbox_TextChanged);
            // 
            // Student_username_textbox
            // 
            this.Student_username_textbox.BorderRadius = 10;
            this.Student_username_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Student_username_textbox.DefaultText = "";
            this.Student_username_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Student_username_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Student_username_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Student_username_textbox.DisabledState.Parent = this.Student_username_textbox;
            this.Student_username_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Student_username_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Student_username_textbox.FocusedState.Parent = this.Student_username_textbox;
            this.Student_username_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Student_username_textbox.HoverState.Parent = this.Student_username_textbox;
            this.Student_username_textbox.Location = new System.Drawing.Point(230, 176);
            this.Student_username_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Student_username_textbox.Name = "Student_username_textbox";
            this.Student_username_textbox.PasswordChar = '\0';
            this.Student_username_textbox.PlaceholderText = "Username";
            this.Student_username_textbox.SelectedText = "";
            this.Student_username_textbox.ShadowDecoration.Parent = this.Student_username_textbox;
            this.Student_username_textbox.Size = new System.Drawing.Size(278, 47);
            this.Student_username_textbox.TabIndex = 26;
            this.Student_username_textbox.TextChanged += new System.EventHandler(this.Student_username_textbox_TextChanged);
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(305, 133);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(103, 22);
            this.guna2HtmlLabel1.TabIndex = 25;
            this.guna2HtmlLabel1.Text = "Student Login";
            this.guna2HtmlLabel1.Click += new System.EventHandler(this.guna2HtmlLabel1_Click);
            // 
            // bt_stu_login
            // 
            this.bt_stu_login.BorderRadius = 20;
            this.bt_stu_login.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            this.bt_stu_login.CheckedState.Parent = this.bt_stu_login;
            this.bt_stu_login.CustomImages.Parent = this.bt_stu_login;
            this.bt_stu_login.FillColor = System.Drawing.Color.Fuchsia;
            this.bt_stu_login.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_stu_login.ForeColor = System.Drawing.Color.Black;
            this.bt_stu_login.HoverState.Parent = this.bt_stu_login;
            this.bt_stu_login.Location = new System.Drawing.Point(277, 329);
            this.bt_stu_login.Name = "bt_stu_login";
            this.bt_stu_login.ShadowDecoration.Parent = this.bt_stu_login;
            this.bt_stu_login.Size = new System.Drawing.Size(180, 45);
            this.bt_stu_login.TabIndex = 24;
            this.bt_stu_login.Text = "LOGIN";
            this.bt_stu_login.Click += new System.EventHandler(this.bt_stu_login_Click);
            // 
            // stu_password_textbox
            // 
            this.stu_password_textbox.BorderRadius = 10;
            this.stu_password_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.stu_password_textbox.DefaultText = "**********";
            this.stu_password_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.stu_password_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.stu_password_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.stu_password_textbox.DisabledState.Parent = this.stu_password_textbox;
            this.stu_password_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.stu_password_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.stu_password_textbox.FocusedState.Parent = this.stu_password_textbox;
            this.stu_password_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.stu_password_textbox.HoverState.Parent = this.stu_password_textbox;
            this.stu_password_textbox.Location = new System.Drawing.Point(230, 248);
            this.stu_password_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.stu_password_textbox.Name = "stu_password_textbox";
            this.stu_password_textbox.PasswordChar = '\0';
            this.stu_password_textbox.PlaceholderText = "";
            this.stu_password_textbox.SelectedText = "";
            this.stu_password_textbox.SelectionStart = 10;
            this.stu_password_textbox.ShadowDecoration.Parent = this.stu_password_textbox;
            this.stu_password_textbox.Size = new System.Drawing.Size(278, 47);
            this.stu_password_textbox.TabIndex = 23;
            this.stu_password_textbox.TextChanged += new System.EventHandler(this.stu_password_textbox_TextChanged);
            // 
            // Stu_username_textbox
            // 
            this.Stu_username_textbox.BorderRadius = 10;
            this.Stu_username_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Stu_username_textbox.DefaultText = "Username";
            this.Stu_username_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Stu_username_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Stu_username_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Stu_username_textbox.DisabledState.Parent = this.Stu_username_textbox;
            this.Stu_username_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Stu_username_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Stu_username_textbox.FocusedState.Parent = this.Stu_username_textbox;
            this.Stu_username_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Stu_username_textbox.HoverState.Parent = this.Stu_username_textbox;
            this.Stu_username_textbox.Location = new System.Drawing.Point(230, 176);
            this.Stu_username_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Stu_username_textbox.Name = "Stu_username_textbox";
            this.Stu_username_textbox.PasswordChar = '\0';
            this.Stu_username_textbox.PlaceholderText = "";
            this.Stu_username_textbox.SelectedText = "";
            this.Stu_username_textbox.SelectionStart = 8;
            this.Stu_username_textbox.ShadowDecoration.Parent = this.Stu_username_textbox;
            this.Stu_username_textbox.Size = new System.Drawing.Size(278, 47);
            this.Stu_username_textbox.TabIndex = 22;
            this.Stu_username_textbox.TextChanged += new System.EventHandler(this.Stu_username_textbox_TextChanged);
            // 
            // uc_login_student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.guna2HtmlLabel2);
            this.Controls.Add(this.bt_student_login);
            this.Controls.Add(this.Student_password_textbox);
            this.Controls.Add(this.Student_username_textbox);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.bt_stu_login);
            this.Controls.Add(this.stu_password_textbox);
            this.Controls.Add(this.Stu_username_textbox);
            this.Name = "uc_login_student";
            this.Size = new System.Drawing.Size(738, 507);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Guna.UI2.WinForms.Guna2Elipse uc_student_login;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2Button bt_student_login;
        private Guna.UI2.WinForms.Guna2TextBox Student_password_textbox;
        private Guna.UI2.WinForms.Guna2TextBox Student_username_textbox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button bt_stu_login;
        private Guna.UI2.WinForms.Guna2TextBox stu_password_textbox;
        private Guna.UI2.WinForms.Guna2TextBox Stu_username_textbox;
    }
}
