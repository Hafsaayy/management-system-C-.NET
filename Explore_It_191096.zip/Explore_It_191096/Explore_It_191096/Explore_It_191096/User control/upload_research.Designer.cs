﻿
namespace Explore_It_191096.User_control
{
    partial class upload_research
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.res_discritption_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.path_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Upload_research_button = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.uplaodfile_button = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.SuspendLayout();
            // 
            // res_discritption_textbox
            // 
            this.res_discritption_textbox.BorderColor = System.Drawing.Color.Black;
            this.res_discritption_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.res_discritption_textbox.DefaultText = "";
            this.res_discritption_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.res_discritption_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.res_discritption_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.res_discritption_textbox.DisabledState.Parent = this.res_discritption_textbox;
            this.res_discritption_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.res_discritption_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.res_discritption_textbox.FocusedState.Parent = this.res_discritption_textbox;
            this.res_discritption_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.res_discritption_textbox.HoverState.Parent = this.res_discritption_textbox;
            this.res_discritption_textbox.Location = new System.Drawing.Point(93, 149);
            this.res_discritption_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.res_discritption_textbox.Name = "res_discritption_textbox";
            this.res_discritption_textbox.PasswordChar = '\0';
            this.res_discritption_textbox.PlaceholderText = "enter research paper ";
            this.res_discritption_textbox.SelectedText = "";
            this.res_discritption_textbox.ShadowDecoration.Parent = this.res_discritption_textbox;
            this.res_discritption_textbox.Size = new System.Drawing.Size(652, 345);
            this.res_discritption_textbox.TabIndex = 0;
            this.res_discritption_textbox.TextChanged += new System.EventHandler(this.res_discritption_textbox_TextChanged);
            // 
            // path_textbox
            // 
            this.path_textbox.BorderColor = System.Drawing.Color.Black;
            this.path_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.path_textbox.DefaultText = "";
            this.path_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.path_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.path_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.path_textbox.DisabledState.Parent = this.path_textbox;
            this.path_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.path_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.path_textbox.FocusedState.Parent = this.path_textbox;
            this.path_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.path_textbox.HoverState.Parent = this.path_textbox;
            this.path_textbox.Location = new System.Drawing.Point(93, 103);
            this.path_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.path_textbox.Name = "path_textbox";
            this.path_textbox.PasswordChar = '\0';
            this.path_textbox.PlaceholderText = "Research paper";
            this.path_textbox.SelectedText = "";
            this.path_textbox.ShadowDecoration.Parent = this.path_textbox;
            this.path_textbox.Size = new System.Drawing.Size(652, 36);
            this.path_textbox.TabIndex = 1;
            this.path_textbox.TextChanged += new System.EventHandler(this.path_textbox_TextChanged);
            // 
            // Upload_research_button
            // 
            this.Upload_research_button.CheckedState.Parent = this.Upload_research_button;
            this.Upload_research_button.CustomImages.Parent = this.Upload_research_button;
            this.Upload_research_button.FillColor = System.Drawing.Color.Fuchsia;
            this.Upload_research_button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Upload_research_button.ForeColor = System.Drawing.Color.White;
            this.Upload_research_button.HoverState.Parent = this.Upload_research_button;
            this.Upload_research_button.Location = new System.Drawing.Point(565, 502);
            this.Upload_research_button.Name = "Upload_research_button";
            this.Upload_research_button.ShadowDecoration.Parent = this.Upload_research_button;
            this.Upload_research_button.Size = new System.Drawing.Size(180, 45);
            this.Upload_research_button.TabIndex = 2;
            this.Upload_research_button.Text = "Upload";
            this.Upload_research_button.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this;
            // 
            // uplaodfile_button
            // 
            this.uplaodfile_button.CheckedState.Parent = this.uplaodfile_button;
            this.uplaodfile_button.CustomImages.Parent = this.uplaodfile_button;
            this.uplaodfile_button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.uplaodfile_button.ForeColor = System.Drawing.Color.White;
            this.uplaodfile_button.HoverState.Parent = this.uplaodfile_button;
            this.uplaodfile_button.Location = new System.Drawing.Point(149, 502);
            this.uplaodfile_button.Name = "uplaodfile_button";
            this.uplaodfile_button.ShadowDecoration.Parent = this.uplaodfile_button;
            this.uplaodfile_button.Size = new System.Drawing.Size(180, 45);
            this.uplaodfile_button.TabIndex = 3;
            this.uplaodfile_button.Text = "Upload file";
            this.uplaodfile_button.Click += new System.EventHandler(this.uplaodfile_button_Click);
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(235, 65);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(367, 30);
            this.guna2HtmlLabel1.TabIndex = 4;
            this.guna2HtmlLabel1.Text = "Upload Research and thesis";
            this.guna2HtmlLabel1.Click += new System.EventHandler(this.guna2HtmlLabel1_Click);
            // 
            // upload_research
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.uplaodfile_button);
            this.Controls.Add(this.Upload_research_button);
            this.Controls.Add(this.path_textbox);
            this.Controls.Add(this.res_discritption_textbox);
            this.Name = "upload_research";
            this.Size = new System.Drawing.Size(949, 575);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox res_discritption_textbox;
        private Guna.UI2.WinForms.Guna2TextBox path_textbox;
        private Guna.UI2.WinForms.Guna2Button Upload_research_button;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Button uplaodfile_button;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
    }
}
