﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
namespace Explore_It_191096.User_control
{
    public partial class upload_research : UserControl
    {
        string file;
        database db = new database();
        public upload_research()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            String q = "Select UID from [loginprofile] where Login__ID = (Select Max(Login__ID) from [loginprofile])";
            DataSet d = db.Get_Data(q);

            int id = Convert.ToInt32(d.Tables[0].Rows[0]["Uid"]);
            if (res_discritption_textbox.Text != "" && path_textbox.Text != "")
            {
                string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\hafsa\Downloads\Explore_It_191096\Explore_It_191096\maani.mdf;Integrated Security=True;Connect Timeout=30";
                string filePath = path_textbox.Text;
                // string connectionString = "";
                FileStream stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                BinaryReader reader = new BinaryReader(stream);
                byte[] file = reader.ReadBytes((int)stream.Length);
                reader.Close();
                stream.Close();

                String Query = "Insert into Article(Res_id, Article_heading, Article_discription, [file])  values" +
                    "(" + id + ",'" + res_discritption_textbox.Text + "','" + path_textbox.Text + "', @File)";
                //ldb.set_Data(Query);
                SqlCommand command;
                SqlConnection connection = new SqlConnection(connectionString);
                command = new SqlCommand(Query, connection);
                command.Parameters.Add("@File", SqlDbType.Binary, file.Length).Value = file;
                connection.Open();
                command.ExecuteNonQuery();

                MessageBox.Show("Research Submitted Sucessfully..");
            }
        }

        private void uplaodfile_button_Click(object sender, EventArgs e)
        {
            Stream st;
            OpenFileDialog pd = new OpenFileDialog();
            if(pd.ShowDialog() == DialogResult.OK)
            {
                if((st=pd.OpenFile())!=null)
                {
                     file = pd.FileName.ToString();
                    path_textbox.Text = file;
                    
                }
            }
        }

        private void res_discritption_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void path_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }
    }
}
