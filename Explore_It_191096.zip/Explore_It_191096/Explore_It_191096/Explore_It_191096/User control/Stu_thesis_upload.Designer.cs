﻿
namespace Explore_It_191096.User_control
{
    partial class Stu_thesis_upload
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Upload_thesis_button = new Guna.UI2.WinForms.Guna2Button();
            this.thesis_paper_heading_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.thesis_discritption_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.SuspendLayout();
            // 
            // Upload_thesis_button
            // 
            this.Upload_thesis_button.CheckedState.Parent = this.Upload_thesis_button;
            this.Upload_thesis_button.CustomImages.Parent = this.Upload_thesis_button;
            this.Upload_thesis_button.FillColor = System.Drawing.Color.Fuchsia;
            this.Upload_thesis_button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Upload_thesis_button.ForeColor = System.Drawing.Color.White;
            this.Upload_thesis_button.HoverState.Parent = this.Upload_thesis_button;
            this.Upload_thesis_button.Location = new System.Drawing.Point(572, 469);
            this.Upload_thesis_button.Name = "Upload_thesis_button";
            this.Upload_thesis_button.ShadowDecoration.Parent = this.Upload_thesis_button;
            this.Upload_thesis_button.Size = new System.Drawing.Size(180, 45);
            this.Upload_thesis_button.TabIndex = 5;
            this.Upload_thesis_button.Text = "Upload";
            this.Upload_thesis_button.Click += new System.EventHandler(this.Upload_thesis_button_Click);
            // 
            // thesis_paper_heading_textbox
            // 
            this.thesis_paper_heading_textbox.BorderColor = System.Drawing.Color.Black;
            this.thesis_paper_heading_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.thesis_paper_heading_textbox.DefaultText = "";
            this.thesis_paper_heading_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.thesis_paper_heading_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.thesis_paper_heading_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.thesis_paper_heading_textbox.DisabledState.Parent = this.thesis_paper_heading_textbox;
            this.thesis_paper_heading_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.thesis_paper_heading_textbox.FillColor = System.Drawing.Color.Gainsboro;
            this.thesis_paper_heading_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.thesis_paper_heading_textbox.FocusedState.Parent = this.thesis_paper_heading_textbox;
            this.thesis_paper_heading_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.thesis_paper_heading_textbox.HoverState.Parent = this.thesis_paper_heading_textbox;
            this.thesis_paper_heading_textbox.Location = new System.Drawing.Point(100, 70);
            this.thesis_paper_heading_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.thesis_paper_heading_textbox.Name = "thesis_paper_heading_textbox";
            this.thesis_paper_heading_textbox.PasswordChar = '\0';
            this.thesis_paper_heading_textbox.PlaceholderForeColor = System.Drawing.Color.Black;
            this.thesis_paper_heading_textbox.PlaceholderText = "Thesis paper";
            this.thesis_paper_heading_textbox.SelectedText = "";
            this.thesis_paper_heading_textbox.ShadowDecoration.Parent = this.thesis_paper_heading_textbox;
            this.thesis_paper_heading_textbox.Size = new System.Drawing.Size(652, 36);
            this.thesis_paper_heading_textbox.TabIndex = 4;
            this.thesis_paper_heading_textbox.TextChanged += new System.EventHandler(this.thesis_paper_heading_textbox_TextChanged);
            // 
            // thesis_discritption_textbox
            // 
            this.thesis_discritption_textbox.BorderColor = System.Drawing.Color.Black;
            this.thesis_discritption_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.thesis_discritption_textbox.DefaultText = "";
            this.thesis_discritption_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.thesis_discritption_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.thesis_discritption_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.thesis_discritption_textbox.DisabledState.Parent = this.thesis_discritption_textbox;
            this.thesis_discritption_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.thesis_discritption_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.thesis_discritption_textbox.FocusedState.Parent = this.thesis_discritption_textbox;
            this.thesis_discritption_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.thesis_discritption_textbox.HoverState.Parent = this.thesis_discritption_textbox;
            this.thesis_discritption_textbox.Location = new System.Drawing.Point(100, 116);
            this.thesis_discritption_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.thesis_discritption_textbox.Name = "thesis_discritption_textbox";
            this.thesis_discritption_textbox.PasswordChar = '\0';
            this.thesis_discritption_textbox.PlaceholderText = "enter thesis paper ";
            this.thesis_discritption_textbox.SelectedText = "";
            this.thesis_discritption_textbox.ShadowDecoration.Parent = this.thesis_discritption_textbox;
            this.thesis_discritption_textbox.Size = new System.Drawing.Size(652, 345);
            this.thesis_discritption_textbox.TabIndex = 3;
            this.thesis_discritption_textbox.TextChanged += new System.EventHandler(this.thesis_discritption_textbox_TextChanged);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this;
            // 
            // Stu_thesis_upload
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.Upload_thesis_button);
            this.Controls.Add(this.thesis_paper_heading_textbox);
            this.Controls.Add(this.thesis_discritption_textbox);
            this.Name = "Stu_thesis_upload";
            this.Size = new System.Drawing.Size(852, 584);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Button Upload_thesis_button;
        private Guna.UI2.WinForms.Guna2TextBox thesis_paper_heading_textbox;
        private Guna.UI2.WinForms.Guna2TextBox thesis_discritption_textbox;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
    }
}
