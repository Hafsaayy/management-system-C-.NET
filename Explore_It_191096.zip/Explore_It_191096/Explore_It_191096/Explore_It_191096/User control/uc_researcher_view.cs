﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096.User_control
{
    public partial class uc_researcher_view : UserControl
    {
        database Database = new database();
        public uc_researcher_view()
        {
            InitializeComponent();
        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void Researcher_gridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void uc_researcher_view_Load(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Researcher";
            DataSet ds = Database.Get_Data(query);
            Researcher_gridview.DataSource = ds.Tables[0];
        }

        private void guna2HtmlLabel1_Click_1(object sender, EventArgs e)
        {
           
        }
    }
}
