﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096.User_control
{
    public partial class show_media : UserControl
    {
        database datab = new database();
        public show_media()
        {
            InitializeComponent();
        }

        private void show_media_Load(object sender, EventArgs e)
        {
            string query = "SELECT ";
        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {
            
        }

       
    }
}
