﻿
namespace Explore_It_191096
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.bt_logout_admin = new Guna.UI2.WinForms.Guna2Button();
            this.bt_admin_image = new Guna.UI2.WinForms.Guna2ImageButton();
            this.bt_admin_media = new Guna.UI2.WinForms.Guna2Button();
            this.bt_admin_forums = new Guna.UI2.WinForms.Guna2Button();
            this.bt_admin_researches = new Guna.UI2.WinForms.Guna2Button();
            this.bt_exploreit_admin = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.uc_forum_view2 = new Explore_It_191096.User_control.uc_forum_view();
            this.upload_research1 = new Explore_It_191096.User_control.upload_research();
            this.uc_forum_view1 = new Explore_It_191096.User_control.uc_forum_view();
            this.uc_student_view1 = new Explore_It_191096.User_control.uc_student_view();
            this.uc_researcher_view1 = new Explore_It_191096.User_control.uc_researcher_view();
            this.uc_share_Research1 = new Explore_It_191096.User_control.uc_share_Research();
            this.res_gridview = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.student_gridview = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse3 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Panel1.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Controls.Add(this.guna2Button1);
            this.guna2Panel1.Controls.Add(this.bt_logout_admin);
            this.guna2Panel1.Controls.Add(this.bt_admin_image);
            this.guna2Panel1.Controls.Add(this.bt_admin_media);
            this.guna2Panel1.Controls.Add(this.bt_admin_forums);
            this.guna2Panel1.Controls.Add(this.bt_admin_researches);
            this.guna2Panel1.Controls.Add(this.bt_exploreit_admin);
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(206, 557);
            this.guna2Panel1.TabIndex = 0;
            this.guna2Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2Panel1_Paint);
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderRadius = 20;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.Black;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(21, 277);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(165, 45);
            this.guna2Button1.TabIndex = 12;
            this.guna2Button1.Text = "Student";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // bt_logout_admin
            // 
            this.bt_logout_admin.BorderRadius = 20;
            this.bt_logout_admin.CheckedState.Parent = this.bt_logout_admin;
            this.bt_logout_admin.CustomImages.Parent = this.bt_logout_admin;
            this.bt_logout_admin.FillColor = System.Drawing.Color.Red;
            this.bt_logout_admin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_logout_admin.ForeColor = System.Drawing.Color.White;
            this.bt_logout_admin.HoverState.Parent = this.bt_logout_admin;
            this.bt_logout_admin.Location = new System.Drawing.Point(22, 497);
            this.bt_logout_admin.Name = "bt_logout_admin";
            this.bt_logout_admin.ShadowDecoration.Parent = this.bt_logout_admin;
            this.bt_logout_admin.Size = new System.Drawing.Size(165, 45);
            this.bt_logout_admin.TabIndex = 11;
            this.bt_logout_admin.Text = "Log Out";
            this.bt_logout_admin.Click += new System.EventHandler(this.bt_logout_admin_Click);
            // 
            // bt_admin_image
            // 
            this.bt_admin_image.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.bt_admin_image.CheckedState.Parent = this.bt_admin_image;
            this.bt_admin_image.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.bt_admin_image.HoverState.Parent = this.bt_admin_image;
            this.bt_admin_image.Image = ((System.Drawing.Image)(resources.GetObject("bt_admin_image.Image")));
            this.bt_admin_image.ImageRotate = 0F;
            this.bt_admin_image.ImageSize = new System.Drawing.Size(80, 80);
            this.bt_admin_image.Location = new System.Drawing.Point(32, 21);
            this.bt_admin_image.Name = "bt_admin_image";
            this.bt_admin_image.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.bt_admin_image.PressedState.Parent = this.bt_admin_image;
            this.bt_admin_image.Size = new System.Drawing.Size(142, 114);
            this.bt_admin_image.TabIndex = 10;
            // 
            // bt_admin_media
            // 
            this.bt_admin_media.BorderRadius = 20;
            this.bt_admin_media.CheckedState.Parent = this.bt_admin_media;
            this.bt_admin_media.CustomImages.Parent = this.bt_admin_media;
            this.bt_admin_media.FillColor = System.Drawing.Color.Black;
            this.bt_admin_media.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_admin_media.ForeColor = System.Drawing.Color.White;
            this.bt_admin_media.HoverState.Parent = this.bt_admin_media;
            this.bt_admin_media.Location = new System.Drawing.Point(12, 338);
            this.bt_admin_media.Name = "bt_admin_media";
            this.bt_admin_media.ShadowDecoration.Parent = this.bt_admin_media;
            this.bt_admin_media.Size = new System.Drawing.Size(182, 45);
            this.bt_admin_media.TabIndex = 9;
            this.bt_admin_media.Text = "researches uploaded";
            this.bt_admin_media.Click += new System.EventHandler(this.bt_admin_media_Click);
            // 
            // bt_admin_forums
            // 
            this.bt_admin_forums.BorderRadius = 20;
            this.bt_admin_forums.CheckedState.Parent = this.bt_admin_forums;
            this.bt_admin_forums.CustomImages.Parent = this.bt_admin_forums;
            this.bt_admin_forums.FillColor = System.Drawing.Color.Black;
            this.bt_admin_forums.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_admin_forums.ForeColor = System.Drawing.Color.White;
            this.bt_admin_forums.HoverState.Parent = this.bt_admin_forums;
            this.bt_admin_forums.Location = new System.Drawing.Point(22, 400);
            this.bt_admin_forums.Name = "bt_admin_forums";
            this.bt_admin_forums.ShadowDecoration.Parent = this.bt_admin_forums;
            this.bt_admin_forums.Size = new System.Drawing.Size(165, 45);
            this.bt_admin_forums.TabIndex = 8;
            this.bt_admin_forums.Text = "Forums";
            this.bt_admin_forums.Click += new System.EventHandler(this.bt_admin_forums_Click);
            // 
            // bt_admin_researches
            // 
            this.bt_admin_researches.BorderRadius = 20;
            this.bt_admin_researches.CheckedState.Parent = this.bt_admin_researches;
            this.bt_admin_researches.CustomImages.Parent = this.bt_admin_researches;
            this.bt_admin_researches.FillColor = System.Drawing.Color.Black;
            this.bt_admin_researches.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_admin_researches.ForeColor = System.Drawing.Color.White;
            this.bt_admin_researches.HoverState.Parent = this.bt_admin_researches;
            this.bt_admin_researches.Location = new System.Drawing.Point(22, 214);
            this.bt_admin_researches.Name = "bt_admin_researches";
            this.bt_admin_researches.ShadowDecoration.Parent = this.bt_admin_researches;
            this.bt_admin_researches.Size = new System.Drawing.Size(165, 45);
            this.bt_admin_researches.TabIndex = 7;
            this.bt_admin_researches.Text = "Researches";
            this.bt_admin_researches.Click += new System.EventHandler(this.bt_admin_researches_Click);
            // 
            // bt_exploreit_admin
            // 
            this.bt_exploreit_admin.BorderRadius = 20;
            this.bt_exploreit_admin.CheckedState.Parent = this.bt_exploreit_admin;
            this.bt_exploreit_admin.CustomImages.Parent = this.bt_exploreit_admin;
            this.bt_exploreit_admin.FillColor = System.Drawing.Color.Black;
            this.bt_exploreit_admin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_exploreit_admin.ForeColor = System.Drawing.Color.White;
            this.bt_exploreit_admin.HoverState.Parent = this.bt_exploreit_admin;
            this.bt_exploreit_admin.Location = new System.Drawing.Point(22, 147);
            this.bt_exploreit_admin.Name = "bt_exploreit_admin";
            this.bt_exploreit_admin.ShadowDecoration.Parent = this.bt_exploreit_admin;
            this.bt_exploreit_admin.Size = new System.Drawing.Size(165, 45);
            this.bt_exploreit_admin.TabIndex = 6;
            this.bt_exploreit_admin.Text = "Explore IT";
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.uc_forum_view2);
            this.guna2Panel2.Controls.Add(this.upload_research1);
            this.guna2Panel2.Controls.Add(this.uc_forum_view1);
            this.guna2Panel2.Controls.Add(this.uc_student_view1);
            this.guna2Panel2.Controls.Add(this.uc_researcher_view1);
            this.guna2Panel2.Controls.Add(this.uc_share_Research1);
            this.guna2Panel2.Location = new System.Drawing.Point(212, 0);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.ShadowDecoration.Parent = this.guna2Panel2;
            this.guna2Panel2.Size = new System.Drawing.Size(897, 557);
            this.guna2Panel2.TabIndex = 1;
            // 
            // uc_forum_view2
            // 
            this.uc_forum_view2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uc_forum_view2.Location = new System.Drawing.Point(3, 12);
            this.uc_forum_view2.Name = "uc_forum_view2";
            this.uc_forum_view2.Size = new System.Drawing.Size(860, 538);
            this.uc_forum_view2.TabIndex = 5;
            // 
            // upload_research1
            // 
            this.upload_research1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.upload_research1.Location = new System.Drawing.Point(0, 0);
            this.upload_research1.Name = "upload_research1";
            this.upload_research1.Size = new System.Drawing.Size(949, 575);
            this.upload_research1.TabIndex = 4;
            // 
            // uc_forum_view1
            // 
            this.uc_forum_view1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uc_forum_view1.Location = new System.Drawing.Point(3, 4);
            this.uc_forum_view1.Name = "uc_forum_view1";
            this.uc_forum_view1.Size = new System.Drawing.Size(860, 538);
            this.uc_forum_view1.TabIndex = 3;
            // 
            // uc_student_view1
            // 
            this.uc_student_view1.Location = new System.Drawing.Point(0, 12);
            this.uc_student_view1.Name = "uc_student_view1";
            this.uc_student_view1.Size = new System.Drawing.Size(830, 496);
            this.uc_student_view1.TabIndex = 2;
            // 
            // uc_researcher_view1
            // 
            this.uc_researcher_view1.Location = new System.Drawing.Point(0, -43);
            this.uc_researcher_view1.Name = "uc_researcher_view1";
            this.uc_researcher_view1.Size = new System.Drawing.Size(980, 597);
            this.uc_researcher_view1.TabIndex = 1;
            // 
            // uc_share_Research1
            // 
            this.uc_share_Research1.Location = new System.Drawing.Point(3, 0);
            this.uc_share_Research1.Name = "uc_share_Research1";
            this.uc_share_Research1.Size = new System.Drawing.Size(919, 557);
            this.uc_share_Research1.TabIndex = 0;
            // 
            // res_gridview
            // 
            this.res_gridview.TargetControl = this;
            // 
            // student_gridview
            // 
            this.student_gridview.TargetControl = this;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.TargetControl = this;
            // 
            // guna2Elipse3
            // 
            this.guna2Elipse3.TargetControl = this;
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1195, 569);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.guna2Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Admin";
            this.Text = "Admin";
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2ImageButton bt_admin_image;
        private Guna.UI2.WinForms.Guna2Button bt_admin_media;
        private Guna.UI2.WinForms.Guna2Button bt_admin_forums;
        private Guna.UI2.WinForms.Guna2Button bt_admin_researches;
        private Guna.UI2.WinForms.Guna2Button bt_exploreit_admin;
        private Guna.UI2.WinForms.Guna2Button bt_logout_admin;
        private User_control.uc_share_Research uc_share_Research1;
        private User_control.uc_researcher_view uc_researcher_view1;
        private Guna.UI2.WinForms.Guna2Elipse res_gridview;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private User_control.uc_student_view uc_student_view1;
        private Guna.UI2.WinForms.Guna2Elipse student_gridview;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private User_control.uc_forum_view uc_forum_view1;
        private User_control.upload_research upload_research1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private User_control.uc_forum_view uc_forum_view2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse3;
    }
}