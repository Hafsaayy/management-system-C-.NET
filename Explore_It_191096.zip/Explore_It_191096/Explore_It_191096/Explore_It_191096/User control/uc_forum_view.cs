﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Explore_It_191096.User_control
{
    public partial class uc_forum_view : UserControl
    {
        database databse = new database();
        public uc_forum_view()
        {
            InitializeComponent();
        }

        private void uc_forum_view_Load(object sender, EventArgs e)
        {
            String query = "Select * from Forums";
            DataSet ds = databse.Get_Data(query);
            guna2DataGridView1.DataSource = ds.Tables[0];
        }

        private void Add_forum_button_Click(object sender, EventArgs e)
        {
            if (Add_forum_textbox.Text != "")
            {
                String Query = "Insert Into Forums(forum_Name) values ('" + Add_forum_textbox.Text + "')";
                databse.set_Data(Query);
                String query = "Select * from Forums";
                DataSet ds = databse.Get_Data(query);
                guna2DataGridView1.DataSource = ds.Tables[0];

            }
            else
            {
                MessageBox.Show("Please Enter Heading..");
            }
        }

        private void Add_forum_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
