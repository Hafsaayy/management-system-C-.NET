﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096
{
    public partial class Researcher : Form
    {
        public Researcher()
        {
            InitializeComponent();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Visible = true;
        }

        private void bt_give_consultancy_Click(object sender, EventArgs e)
        {
            MessageBox.Show("THIS SERVICE IS TEMPORARYILY UNAVAILALE ....... SORRY FOR INCONVINIENCE");
        }

        private void bt_researcher_forums_Click(object sender, EventArgs e)
        {
            uc_forum_view1.Visible = true;
            uc_forum_view1.BringToFront();
            
        }

        private void bt_share_research_Click(object sender, EventArgs e)
        {
            upload_research1.Visible = true;
            upload_research1.BringToFront();
        }
    }
}
