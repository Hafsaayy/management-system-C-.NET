﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096
{
    public partial class Admin : Form
    {
        database Database = new database();
        public Admin()
        {
            InitializeComponent();
        }

        private void bt_logout_admin_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Visible = true;
            this.Hide();
        }

        private void bt_admin_researches_Click(object sender, EventArgs e)
        {
            uc_researcher_view1.Visible = true;
            uc_researcher_view1.BringToFront();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            uc_student_view1.Visible = true;
            uc_student_view1.BringToFront();
        }

        private void bt_admin_media_Click(object sender, EventArgs e)
        {
            upload_research1.Visible = true;
            upload_research1.BringToFront();
        }

        private void bt_admin_forums_Click(object sender, EventArgs e)
        {
            uc_forum_view1.Visible = true;
            uc_forum_view1.BringToFront();
        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
