﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096.User_control
{
    public partial class uc_signup_researcher : UserControl
    {
        public uc_signup_researcher()
        {
            InitializeComponent();
        }
    }
}
