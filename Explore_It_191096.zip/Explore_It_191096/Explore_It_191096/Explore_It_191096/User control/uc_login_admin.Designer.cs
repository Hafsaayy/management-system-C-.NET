﻿
namespace Explore_It_191096.User_control
{
    partial class uc_login_admin
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bt_Admin_login = new Guna.UI2.WinForms.Guna2Button();
            this.Admin_password_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Admin_username_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.uc_admin_login = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.SuspendLayout();
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(305, 119);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(148, 33);
            this.guna2HtmlLabel1.TabIndex = 17;
            this.guna2HtmlLabel1.Text = "Admin Login";
            this.guna2HtmlLabel1.Click += new System.EventHandler(this.guna2HtmlLabel1_Click);
            // 
            // bt_Admin_login
            // 
            this.bt_Admin_login.BorderRadius = 20;
            this.bt_Admin_login.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            this.bt_Admin_login.CheckedState.Parent = this.bt_Admin_login;
            this.bt_Admin_login.CustomImages.Parent = this.bt_Admin_login;
            this.bt_Admin_login.FillColor = System.Drawing.Color.Fuchsia;
            this.bt_Admin_login.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_Admin_login.ForeColor = System.Drawing.Color.Black;
            this.bt_Admin_login.HoverState.Parent = this.bt_Admin_login;
            this.bt_Admin_login.Location = new System.Drawing.Point(293, 323);
            this.bt_Admin_login.Name = "bt_Admin_login";
            this.bt_Admin_login.ShadowDecoration.Parent = this.bt_Admin_login;
            this.bt_Admin_login.Size = new System.Drawing.Size(180, 45);
            this.bt_Admin_login.TabIndex = 16;
            this.bt_Admin_login.Text = "LOGIN";
            this.bt_Admin_login.Click += new System.EventHandler(this.bt_Admin_login_Click);
            // 
            // Admin_password_textbox
            // 
            this.Admin_password_textbox.BorderRadius = 10;
            this.Admin_password_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Admin_password_textbox.DefaultText = "";
            this.Admin_password_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Admin_password_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Admin_password_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Admin_password_textbox.DisabledState.Parent = this.Admin_password_textbox;
            this.Admin_password_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Admin_password_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Admin_password_textbox.FocusedState.Parent = this.Admin_password_textbox;
            this.Admin_password_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Admin_password_textbox.HoverState.Parent = this.Admin_password_textbox;
            this.Admin_password_textbox.Location = new System.Drawing.Point(246, 242);
            this.Admin_password_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Admin_password_textbox.Name = "Admin_password_textbox";
            this.Admin_password_textbox.PasswordChar = '\0';
            this.Admin_password_textbox.PlaceholderText = "**********";
            this.Admin_password_textbox.SelectedText = "";
            this.Admin_password_textbox.ShadowDecoration.Parent = this.Admin_password_textbox;
            this.Admin_password_textbox.Size = new System.Drawing.Size(278, 47);
            this.Admin_password_textbox.TabIndex = 15;
            this.Admin_password_textbox.TextChanged += new System.EventHandler(this.Admin_password_textbox_TextChanged);
            // 
            // Admin_username_textbox
            // 
            this.Admin_username_textbox.BorderRadius = 10;
            this.Admin_username_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Admin_username_textbox.DefaultText = "";
            this.Admin_username_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Admin_username_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Admin_username_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Admin_username_textbox.DisabledState.Parent = this.Admin_username_textbox;
            this.Admin_username_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Admin_username_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Admin_username_textbox.FocusedState.Parent = this.Admin_username_textbox;
            this.Admin_username_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Admin_username_textbox.HoverState.Parent = this.Admin_username_textbox;
            this.Admin_username_textbox.Location = new System.Drawing.Point(246, 170);
            this.Admin_username_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Admin_username_textbox.Name = "Admin_username_textbox";
            this.Admin_username_textbox.PasswordChar = '\0';
            this.Admin_username_textbox.PlaceholderText = "Username";
            this.Admin_username_textbox.SelectedText = "";
            this.Admin_username_textbox.ShadowDecoration.Parent = this.Admin_username_textbox;
            this.Admin_username_textbox.Size = new System.Drawing.Size(278, 47);
            this.Admin_username_textbox.TabIndex = 14;
            this.Admin_username_textbox.TextChanged += new System.EventHandler(this.Admin_username_textbox_TextChanged);
            // 
            // uc_admin_login
            // 
            this.uc_admin_login.TargetControl = this;
            // 
            // uc_login_admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.bt_Admin_login);
            this.Controls.Add(this.Admin_password_textbox);
            this.Controls.Add(this.Admin_username_textbox);
            this.Name = "uc_login_admin";
            this.Size = new System.Drawing.Size(757, 511);
            this.Load += new System.EventHandler(this.uc_login_admin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button bt_Admin_login;
        private Guna.UI2.WinForms.Guna2TextBox Admin_password_textbox;
        private Guna.UI2.WinForms.Guna2TextBox Admin_username_textbox;
        private Guna.UI2.WinForms.Guna2Elipse uc_admin_login;
    }
}
