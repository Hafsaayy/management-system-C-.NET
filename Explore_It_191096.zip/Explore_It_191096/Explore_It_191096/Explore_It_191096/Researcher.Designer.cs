﻿
namespace Explore_It_191096
{
    partial class Researcher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Researcher));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.bt_researcher_image = new Guna.UI2.WinForms.Guna2ImageButton();
            this.bt_share_research = new Guna.UI2.WinForms.Guna2Button();
            this.bt_researcher_forums = new Guna.UI2.WinForms.Guna2Button();
            this.bt_give_consultancy = new Guna.UI2.WinForms.Guna2Button();
            this.bt_exploreit_researcher = new Guna.UI2.WinForms.Guna2Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.uc_forum_view1 = new Explore_It_191096.User_control.uc_forum_view();
            this.upload_research1 = new Explore_It_191096.User_control.upload_research();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Panel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Controls.Add(this.guna2Button1);
            this.guna2Panel1.Controls.Add(this.bt_researcher_image);
            this.guna2Panel1.Controls.Add(this.bt_share_research);
            this.guna2Panel1.Controls.Add(this.bt_researcher_forums);
            this.guna2Panel1.Controls.Add(this.bt_give_consultancy);
            this.guna2Panel1.Controls.Add(this.bt_exploreit_researcher);
            this.guna2Panel1.Location = new System.Drawing.Point(2, 3);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(227, 576);
            this.guna2Panel1.TabIndex = 0;
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderRadius = 20;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.Red;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(37, 429);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(165, 45);
            this.guna2Button1.TabIndex = 6;
            this.guna2Button1.Text = "Log Out";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // bt_researcher_image
            // 
            this.bt_researcher_image.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.bt_researcher_image.CheckedState.Parent = this.bt_researcher_image;
            this.bt_researcher_image.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.bt_researcher_image.HoverState.Parent = this.bt_researcher_image;
            this.bt_researcher_image.Image = ((System.Drawing.Image)(resources.GetObject("bt_researcher_image.Image")));
            this.bt_researcher_image.ImageRotate = 0F;
            this.bt_researcher_image.ImageSize = new System.Drawing.Size(80, 80);
            this.bt_researcher_image.Location = new System.Drawing.Point(48, 21);
            this.bt_researcher_image.Name = "bt_researcher_image";
            this.bt_researcher_image.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.bt_researcher_image.PressedState.Parent = this.bt_researcher_image;
            this.bt_researcher_image.Size = new System.Drawing.Size(142, 114);
            this.bt_researcher_image.TabIndex = 5;
            // 
            // bt_share_research
            // 
            this.bt_share_research.BorderRadius = 20;
            this.bt_share_research.CheckedState.Parent = this.bt_share_research;
            this.bt_share_research.CustomImages.Parent = this.bt_share_research;
            this.bt_share_research.FillColor = System.Drawing.Color.Black;
            this.bt_share_research.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_share_research.ForeColor = System.Drawing.Color.White;
            this.bt_share_research.HoverState.Parent = this.bt_share_research;
            this.bt_share_research.Location = new System.Drawing.Point(37, 305);
            this.bt_share_research.Name = "bt_share_research";
            this.bt_share_research.ShadowDecoration.Parent = this.bt_share_research;
            this.bt_share_research.Size = new System.Drawing.Size(165, 45);
            this.bt_share_research.TabIndex = 4;
            this.bt_share_research.Text = "Research upload";
            this.bt_share_research.Click += new System.EventHandler(this.bt_share_research_Click);
            // 
            // bt_researcher_forums
            // 
            this.bt_researcher_forums.BorderRadius = 20;
            this.bt_researcher_forums.CheckedState.Parent = this.bt_researcher_forums;
            this.bt_researcher_forums.CustomImages.Parent = this.bt_researcher_forums;
            this.bt_researcher_forums.FillColor = System.Drawing.Color.Black;
            this.bt_researcher_forums.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_researcher_forums.ForeColor = System.Drawing.Color.White;
            this.bt_researcher_forums.HoverState.Parent = this.bt_researcher_forums;
            this.bt_researcher_forums.Location = new System.Drawing.Point(37, 372);
            this.bt_researcher_forums.Name = "bt_researcher_forums";
            this.bt_researcher_forums.ShadowDecoration.Parent = this.bt_researcher_forums;
            this.bt_researcher_forums.Size = new System.Drawing.Size(165, 45);
            this.bt_researcher_forums.TabIndex = 3;
            this.bt_researcher_forums.Text = "Forums";
            this.bt_researcher_forums.Click += new System.EventHandler(this.bt_researcher_forums_Click);
            // 
            // bt_give_consultancy
            // 
            this.bt_give_consultancy.BorderRadius = 20;
            this.bt_give_consultancy.CheckedState.Parent = this.bt_give_consultancy;
            this.bt_give_consultancy.CustomImages.Parent = this.bt_give_consultancy;
            this.bt_give_consultancy.FillColor = System.Drawing.Color.Black;
            this.bt_give_consultancy.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_give_consultancy.ForeColor = System.Drawing.Color.White;
            this.bt_give_consultancy.HoverState.Parent = this.bt_give_consultancy;
            this.bt_give_consultancy.Location = new System.Drawing.Point(37, 238);
            this.bt_give_consultancy.Name = "bt_give_consultancy";
            this.bt_give_consultancy.ShadowDecoration.Parent = this.bt_give_consultancy;
            this.bt_give_consultancy.Size = new System.Drawing.Size(165, 45);
            this.bt_give_consultancy.TabIndex = 2;
            this.bt_give_consultancy.Text = "Give Consultancy";
            this.bt_give_consultancy.Click += new System.EventHandler(this.bt_give_consultancy_Click);
            // 
            // bt_exploreit_researcher
            // 
            this.bt_exploreit_researcher.BorderRadius = 20;
            this.bt_exploreit_researcher.CheckedState.Parent = this.bt_exploreit_researcher;
            this.bt_exploreit_researcher.CustomImages.Parent = this.bt_exploreit_researcher;
            this.bt_exploreit_researcher.FillColor = System.Drawing.Color.Black;
            this.bt_exploreit_researcher.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_exploreit_researcher.ForeColor = System.Drawing.Color.White;
            this.bt_exploreit_researcher.HoverState.Parent = this.bt_exploreit_researcher;
            this.bt_exploreit_researcher.Location = new System.Drawing.Point(37, 171);
            this.bt_exploreit_researcher.Name = "bt_exploreit_researcher";
            this.bt_exploreit_researcher.ShadowDecoration.Parent = this.bt_exploreit_researcher;
            this.bt_exploreit_researcher.Size = new System.Drawing.Size(165, 45);
            this.bt_exploreit_researcher.TabIndex = 1;
            this.bt_exploreit_researcher.Text = "Explore IT";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.uc_forum_view1);
            this.panel1.Controls.Add(this.upload_research1);
            this.panel1.Location = new System.Drawing.Point(235, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(899, 576);
            this.panel1.TabIndex = 1;
            // 
            // uc_forum_view1
            // 
            this.uc_forum_view1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uc_forum_view1.Location = new System.Drawing.Point(21, 38);
            this.uc_forum_view1.Name = "uc_forum_view1";
            this.uc_forum_view1.Size = new System.Drawing.Size(860, 538);
            this.uc_forum_view1.TabIndex = 1;
            // 
            // upload_research1
            // 
            this.upload_research1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.upload_research1.Location = new System.Drawing.Point(0, 3);
            this.upload_research1.Name = "upload_research1";
            this.upload_research1.Size = new System.Drawing.Size(949, 575);
            this.upload_research1.TabIndex = 0;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.TargetControl = this;
            // 
            // Researcher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1236, 628);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.guna2Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Researcher";
            this.Text = "Researcher";
            this.guna2Panel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2ImageButton bt_researcher_image;
        private Guna.UI2.WinForms.Guna2Button bt_share_research;
        private Guna.UI2.WinForms.Guna2Button bt_researcher_forums;
        private Guna.UI2.WinForms.Guna2Button bt_give_consultancy;
        private Guna.UI2.WinForms.Guna2Button bt_exploreit_researcher;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private User_control.upload_research upload_research1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private User_control.uc_forum_view uc_forum_view1;
    }
}