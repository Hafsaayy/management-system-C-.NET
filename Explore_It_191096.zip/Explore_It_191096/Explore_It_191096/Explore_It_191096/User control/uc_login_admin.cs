﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096.User_control
{
    public partial class uc_login_admin : UserControl
    {
        public uc_login_admin()
        {
            InitializeComponent();
        }

        private void bt_Admin_login_Click(object sender, EventArgs e)
        {
            database Database = new database();
            if (Admin_username_textbox.Text != "" && Admin_password_textbox.Text != "")
            {

                String username = Admin_username_textbox.Text;
                String password = Admin_password_textbox.Text;
                String Query = "Select * from Admins where username = '" + username + "' and " +
                    "admin_password = '" + password + "'";

                DataSet dt = Database.Get_Data(Query);
                if (dt.Tables[0].Rows.Count != 0)
                {
                    Admin admins = new Admin();
                    this.Hide();
                    int i = Convert.ToInt32(dt.Tables[0].Rows[0]["ID"]);
                    admins.Show();
                    string queryy = "INSERT INTO [Login](u_id) values(" + i + ")";
                    
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password..");
                }
            }
            else
            {

            }
            Admin_username_textbox.Clear();
            Admin_password_textbox.Clear();
            
        }

        private void uc_login_admin_Load(object sender, EventArgs e)
        {

        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void Admin_password_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Admin_username_textbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
