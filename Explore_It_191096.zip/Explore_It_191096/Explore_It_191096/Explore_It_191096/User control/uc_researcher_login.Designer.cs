﻿
namespace Explore_It_191096.User_control
{
    partial class uc_researcher_login
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.uc_login_researcher = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.bt_researcher_login = new Guna.UI2.WinForms.Guna2Button();
            this.Researcher_password_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Researcher_username_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.SuspendLayout();
            // 
            // uc_login_researcher
            // 
            this.uc_login_researcher.TargetControl = this;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(323, 131);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(129, 22);
            this.guna2HtmlLabel1.TabIndex = 13;
            this.guna2HtmlLabel1.Text = "Researcher Login";
            this.guna2HtmlLabel1.Click += new System.EventHandler(this.guna2HtmlLabel1_Click);
            // 
            // bt_researcher_login
            // 
            this.bt_researcher_login.BorderRadius = 20;
            this.bt_researcher_login.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            this.bt_researcher_login.CheckedState.Parent = this.bt_researcher_login;
            this.bt_researcher_login.CustomImages.Parent = this.bt_researcher_login;
            this.bt_researcher_login.FillColor = System.Drawing.Color.Fuchsia;
            this.bt_researcher_login.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_researcher_login.ForeColor = System.Drawing.Color.Black;
            this.bt_researcher_login.HoverState.Parent = this.bt_researcher_login;
            this.bt_researcher_login.Location = new System.Drawing.Point(295, 327);
            this.bt_researcher_login.Name = "bt_researcher_login";
            this.bt_researcher_login.ShadowDecoration.Parent = this.bt_researcher_login;
            this.bt_researcher_login.Size = new System.Drawing.Size(180, 45);
            this.bt_researcher_login.TabIndex = 12;
            this.bt_researcher_login.Text = "LOGIN";
            this.bt_researcher_login.Click += new System.EventHandler(this.bt_researcher_login_Click);
            // 
            // Researcher_password_textbox
            // 
            this.Researcher_password_textbox.BorderRadius = 10;
            this.Researcher_password_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Researcher_password_textbox.DefaultText = "";
            this.Researcher_password_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Researcher_password_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Researcher_password_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Researcher_password_textbox.DisabledState.Parent = this.Researcher_password_textbox;
            this.Researcher_password_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Researcher_password_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Researcher_password_textbox.FocusedState.Parent = this.Researcher_password_textbox;
            this.Researcher_password_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Researcher_password_textbox.HoverState.Parent = this.Researcher_password_textbox;
            this.Researcher_password_textbox.Location = new System.Drawing.Point(248, 246);
            this.Researcher_password_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Researcher_password_textbox.Name = "Researcher_password_textbox";
            this.Researcher_password_textbox.PasswordChar = '\0';
            this.Researcher_password_textbox.PlaceholderText = "**********";
            this.Researcher_password_textbox.SelectedText = "";
            this.Researcher_password_textbox.ShadowDecoration.Parent = this.Researcher_password_textbox;
            this.Researcher_password_textbox.Size = new System.Drawing.Size(278, 47);
            this.Researcher_password_textbox.TabIndex = 11;
            this.Researcher_password_textbox.TextChanged += new System.EventHandler(this.Researcher_password_textbox_TextChanged);
            // 
            // Researcher_username_textbox
            // 
            this.Researcher_username_textbox.BorderRadius = 10;
            this.Researcher_username_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Researcher_username_textbox.DefaultText = "";
            this.Researcher_username_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Researcher_username_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Researcher_username_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Researcher_username_textbox.DisabledState.Parent = this.Researcher_username_textbox;
            this.Researcher_username_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Researcher_username_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Researcher_username_textbox.FocusedState.Parent = this.Researcher_username_textbox;
            this.Researcher_username_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Researcher_username_textbox.HoverState.Parent = this.Researcher_username_textbox;
            this.Researcher_username_textbox.Location = new System.Drawing.Point(248, 174);
            this.Researcher_username_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Researcher_username_textbox.Name = "Researcher_username_textbox";
            this.Researcher_username_textbox.PasswordChar = '\0';
            this.Researcher_username_textbox.PlaceholderText = "Username";
            this.Researcher_username_textbox.SelectedText = "";
            this.Researcher_username_textbox.ShadowDecoration.Parent = this.Researcher_username_textbox;
            this.Researcher_username_textbox.Size = new System.Drawing.Size(278, 47);
            this.Researcher_username_textbox.TabIndex = 10;
            this.Researcher_username_textbox.TextChanged += new System.EventHandler(this.Researcher_username_textbox_TextChanged);
            // 
            // uc_researcher_login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.bt_researcher_login);
            this.Controls.Add(this.Researcher_password_textbox);
            this.Controls.Add(this.Researcher_username_textbox);
            this.Name = "uc_researcher_login";
            this.Size = new System.Drawing.Size(752, 512);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Guna.UI2.WinForms.Guna2Elipse uc_login_researcher;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Button bt_researcher_login;
        private Guna.UI2.WinForms.Guna2TextBox Researcher_password_textbox;
        private Guna.UI2.WinForms.Guna2TextBox Researcher_username_textbox;
    }
}
