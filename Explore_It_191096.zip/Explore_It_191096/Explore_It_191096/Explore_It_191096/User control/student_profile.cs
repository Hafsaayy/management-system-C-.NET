﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096.User_control
{
    public partial class student_profile : UserControl
    {
        database Database = new database();
        public student_profile()
        {
            InitializeComponent();
        }

        private void stu_save_button_profiel_Click(object sender, EventArgs e)
        {
            if (stu_name_textbox_profile.Text != "" && stu_username_tectbox_profile.Text != "" && stu_password_textbox_profile.Text != "")
            {
                try
                {
                    int id = Form1.identity;
                    String n = stu_name_textbox_profile.Text;
                    String u = stu_username_tectbox_profile.Text;
                    String p = stu_password_textbox_profile.Text;
                    String Query = "Update Students Set Stu_name = '" + n + "', Stu_username = '" +
                        u + "', Stu_password = '" + p + "' where id = " + id;
                    Database.set_Data(Query);
                    MessageBox.Show("Profile Updated Sucessfully..");
                }
                catch
                {
                    MessageBox.Show("Error While Updating Data");
                }

            }
            else
            {
                MessageBox.Show("All fields Required");
            }
        }

        private void student_profile_Load(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            int id = Form1.identity;
            String query = "Select * from Students where id = " + id;
            DataSet ds = Database.Get_Data(query);
            String name = ds.Tables[0].Rows[0]["Stu_name"].ToString();
            String username = ds.Tables[0].Rows[0]["Stu_username"].ToString();
            String password = ds.Tables[0].Rows[0]["Stu_password"].ToString();
            STU_id.Text = id.ToString();
            stu_name_textbox_profile.Text = name;
            stu_password_textbox_profile.Text = password;
            stu_username_tectbox_profile.Text = username;
        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void stu_password_textbox_profile_TextChanged(object sender, EventArgs e)
        {

        }

        private void stu_username_tectbox_profile_TextChanged(object sender, EventArgs e)
        {

        }

        private void stu_name_textbox_profile_TextChanged(object sender, EventArgs e)
        {

        }

        private void STU_id_Click(object sender, EventArgs e)
        {

        }
    }
}
