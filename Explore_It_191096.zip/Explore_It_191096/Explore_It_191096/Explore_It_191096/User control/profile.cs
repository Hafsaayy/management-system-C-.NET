﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096.User_control
{
    public partial class profile : UserControl
    {
        database Database = new database();
        public profile()
        {
            InitializeComponent();
        }

        private void save_button_profiel_Click(object sender, EventArgs e)
        {
            if (name_textbox_profile.Text != "" && username_tectbox_profile.Text != "" && password_textbox_profile.Text != "")
            {
                try
                {
                    int id = Form1.identity;
                    String n = name_textbox_profile.Text;
                    String u = username_tectbox_profile.Text;
                    String p = password_textbox_profile.Text;
                    String Query = "Update Admins Set admin_name = '" + n + "', username = '" +
                        u + "', admin_password = '" + p + "' where id = " + id;
                    Database.set_Data(Query);
                    MessageBox.Show("Profile Updated Sucessfully..");
                }
                catch
                {
                    MessageBox.Show("Error While Updating Data");
                }

            }
            else
            {
                MessageBox.Show("All fields Required");
            }
        }

        private void profile_Load(object sender, EventArgs e)
        {
            String q = "Select u_id from [Login] where id = (Select Max(id) from [Login])";
            DataSet d = Database.Get_Data(q);
            int id = Convert.ToInt32(d.Tables[0].Rows[0]["u_id"]);
            Form1 form = new Form1();
            //int id = Form1.identity;
            String query = "Select * from Admins where id = " + id;
            DataSet ds = Database.Get_Data(query);
            String name = ds.Tables[0].Rows[0]["admin_name"].ToString();
            String username = ds.Tables[0].Rows[0]["username"].ToString();
            String password = ds.Tables[0].Rows[0]["admin_password"].ToString();
            admin_id.Text = id.ToString();
            name_textbox_profile.Text = name;
            password_textbox_profile.Text = password; 
            username_tectbox_profile.Text = username;
        } 
    }
}
