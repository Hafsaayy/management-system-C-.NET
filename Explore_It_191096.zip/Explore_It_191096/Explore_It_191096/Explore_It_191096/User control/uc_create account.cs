﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096.User_control
{
    public partial class uc_create_account : UserControl
    {
        public uc_create_account()
        {
            InitializeComponent();
        }

        private void signup_button_Click(object sender, EventArgs e)
        {
            if (Entername_textbox.Text != "" && Enter_password_textbox.Text != "" && Enterusername_textbox.Text != "" && Signin_institute_textbox.Text !="")
            {
                string name = Entername_textbox.Text;
                string username = Enterusername_textbox.Text;
                string passward = Enter_password_textbox.Text;
                string institue = Signin_institute_textbox.Text;
                string query;
                database database = new database();
                if (combobox_textbox.SelectedIndex == 0)
                {
                    try
                    {
                        query = "INSERT INTO Students(Stu_name,Stu_username,Stu_password,Stu_institute) values" +
                             "('" + name + "','" + username + "','" + passward + "','" + institue + "')";
                        database.set_Data(query);
                        MessageBox.Show("Account Created Sucessfully");

                    }
                    catch
                    {
                        MessageBox.Show("Error While Creating Account, Plase try Again");
                    }
                }
                else if (combobox_textbox.SelectedIndex == 1)
                {
                    try
                    {
                        query = "INSERT INTO Researcher(Res_name,Res_username,Res_password,Res_institute) values" +
                            "('" + name + "','" + username + "','" + passward + "','" + institue + "')";
                        database.set_Data(query);
                        MessageBox.Show("Account Created Sucessfully");

                    }
                    catch
                    {
                        MessageBox.Show("Error While Creating Account, Plase try Again");
                    }
                }
                else if (combobox_textbox.SelectedIndex == 2)
                {
                    try
                    {
                        query = "INSERT INTO Admins(admin_name,username,admin_password) values" +
                            "('" + name + "','" + username + "','" + passward + "')";
                        database.set_Data(query);
                        MessageBox.Show("Account Created Sucessfully");

                    }
                    catch
                    {
                        MessageBox.Show("Error While Creating Account, Plase try Again");
                    }
                }


            }
        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void Signin_institute_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void combobox_textbox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Enter_password_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Enterusername_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Entername_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void uc_create_account_Load(object sender, EventArgs e)
        {

        }
    }
}