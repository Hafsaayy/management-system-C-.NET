﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096.User_control
{
    
    public partial class uc_student_view : UserControl
    {
        database db = new database();
        public uc_student_view()
        {
            InitializeComponent();
        }

        private void Stu_gridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void uc_student_view_Load(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Students";
            DataSet ds = db.Get_Data(query);
            Stu_gridview.DataSource = ds.Tables[0];
        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }
    }
}
