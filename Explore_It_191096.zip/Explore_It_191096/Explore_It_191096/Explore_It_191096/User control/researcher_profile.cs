﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096.User_control
{
    public partial class researcher_profile : UserControl
    {
        database Database = new database();
        public researcher_profile()
        {
            Form1 form = new Form1();
            int id = Form1.identity;
            String query = "Select * from Researcher where id = " + id;
            DataSet ds = Database.Get_Data(query);
            String name = ds.Tables[0].Rows[0]["Res_name"].ToString();
            String username = ds.Tables[0].Rows[0]["Res_username"].ToString();
            String password = ds.Tables[0].Rows[0]["Res_password"].ToString();
            res_id.Text = id.ToString();
            res_name_textbox_profile.Text = name;
            res_password_textbox_profile.Text = password;
            res_username_tectbox_profile.Text = username;
            InitializeComponent();
        }

        private void res_save_button_profiel_Click(object sender, EventArgs e)
        {
            if (res_name_textbox_profile.Text != "" && res_username_tectbox_profile.Text != "" && res_password_textbox_profile.Text != "")
            {
                try
                {
                    int id = Form1.identity;
                    String n = res_name_textbox_profile.Text;
                    String u = res_username_tectbox_profile.Text;
                    String p = res_password_textbox_profile.Text;
                    String Query = "Update Researcher Set Res_name = '" + n + "', Res_username = '" +
                        u + "', Res_password = '" + p + "' where id = " + id;
                    Database.set_Data(Query);
                    MessageBox.Show("Profile Updated Sucessfully..");
                }
                catch
                {
                    MessageBox.Show("Error While Updating Data");
                }

            }
            else
            {
                MessageBox.Show("All fields Required");
            }
        }

        private void researcher_profile_Load(object sender, EventArgs e)
        {

        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void res_password_textbox_profile_TextChanged(object sender, EventArgs e)
        {

        }

        private void res_username_tectbox_profile_TextChanged(object sender, EventArgs e)
        {

        }

        private void res_name_textbox_profile_TextChanged(object sender, EventArgs e)
        {

        }

        private void res_id_Click(object sender, EventArgs e)
        {

        }
    }
}
