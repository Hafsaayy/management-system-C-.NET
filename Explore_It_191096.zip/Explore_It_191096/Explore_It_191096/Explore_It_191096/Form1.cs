﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096
{
    public partial class Form1 : Form
    {
        public static int identity;
        public Form1()
        {
            InitializeComponent();
        }

        private void bt_Student_Click(object sender, EventArgs e)
        {
            uc_login_student1.Visible = true;
            uc_login_student1.BringToFront();

        }

        private void bt_researcher_Click(object sender, EventArgs e)
        {
            uc_researcher_login1.Visible = true;
            uc_researcher_login1.BringToFront();
        }

        private void bt_admin_Click(object sender, EventArgs e)
        {
            uc_login_admin1.Visible = true;
            uc_login_admin1.BringToFront();
        }

        private void bt_create_account_Click(object sender, EventArgs e)
        {
           
          
        }

        private void bt_create_account_Click_1(object sender, EventArgs e)
        {
            uc_create_account1.Visible = true;
            uc_create_account1.BringToFront();
           
        }

        private void guna2ImageButton1_Click(object sender, EventArgs e)
        {


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void uc_student_view1_Load(object sender, EventArgs e)
        {

        }

        private void uc_share_Research1_Load(object sender, EventArgs e)
        {

        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
