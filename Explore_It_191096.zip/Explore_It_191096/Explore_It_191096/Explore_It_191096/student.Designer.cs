﻿
namespace Explore_It_191096
{
    partial class student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(student));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.bt_logout_student = new Guna.UI2.WinForms.Guna2Button();
            this.bt_student_image = new Guna.UI2.WinForms.Guna2ImageButton();
            this.bt_take_consultancy_student = new Guna.UI2.WinForms.Guna2Button();
            this.bt_student_forums = new Guna.UI2.WinForms.Guna2Button();
            this.bt_share_thesis_student = new Guna.UI2.WinForms.Guna2Button();
            this.bt_exploreit_student = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.upload_research1 = new Explore_It_191096.User_control.upload_research();
            this.stu_thesis_upload1 = new Explore_It_191096.User_control.Stu_thesis_upload();
            this.uc_forum_view2 = new Explore_It_191096.User_control.uc_forum_view();
            this.uc_forum_view1 = new Explore_It_191096.User_control.uc_forum_view();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse3 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Panel1.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Controls.Add(this.bt_logout_student);
            this.guna2Panel1.Controls.Add(this.bt_student_image);
            this.guna2Panel1.Controls.Add(this.bt_take_consultancy_student);
            this.guna2Panel1.Controls.Add(this.bt_student_forums);
            this.guna2Panel1.Controls.Add(this.bt_share_thesis_student);
            this.guna2Panel1.Controls.Add(this.bt_exploreit_student);
            this.guna2Panel1.Location = new System.Drawing.Point(0, 12);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(228, 581);
            this.guna2Panel1.TabIndex = 0;
            this.guna2Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2Panel1_Paint);
            // 
            // bt_logout_student
            // 
            this.bt_logout_student.BorderRadius = 20;
            this.bt_logout_student.CheckedState.Parent = this.bt_logout_student;
            this.bt_logout_student.CustomImages.Parent = this.bt_logout_student;
            this.bt_logout_student.FillColor = System.Drawing.Color.Red;
            this.bt_logout_student.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_logout_student.ForeColor = System.Drawing.Color.White;
            this.bt_logout_student.HoverState.Parent = this.bt_logout_student;
            this.bt_logout_student.IndicateFocus = true;
            this.bt_logout_student.Location = new System.Drawing.Point(26, 417);
            this.bt_logout_student.Name = "bt_logout_student";
            this.bt_logout_student.ShadowDecoration.Parent = this.bt_logout_student;
            this.bt_logout_student.Size = new System.Drawing.Size(165, 45);
            this.bt_logout_student.TabIndex = 11;
            this.bt_logout_student.Text = "Log Out";
            this.bt_logout_student.Click += new System.EventHandler(this.bt_logout_student_Click);
            // 
            // bt_student_image
            // 
            this.bt_student_image.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.bt_student_image.CheckedState.Parent = this.bt_student_image;
            this.bt_student_image.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.bt_student_image.HoverState.Parent = this.bt_student_image;
            this.bt_student_image.Image = ((System.Drawing.Image)(resources.GetObject("bt_student_image.Image")));
            this.bt_student_image.ImageRotate = 0F;
            this.bt_student_image.ImageSize = new System.Drawing.Size(80, 80);
            this.bt_student_image.Location = new System.Drawing.Point(37, 23);
            this.bt_student_image.Name = "bt_student_image";
            this.bt_student_image.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.bt_student_image.PressedState.Parent = this.bt_student_image;
            this.bt_student_image.Size = new System.Drawing.Size(142, 114);
            this.bt_student_image.TabIndex = 10;
            // 
            // bt_take_consultancy_student
            // 
            this.bt_take_consultancy_student.BorderRadius = 20;
            this.bt_take_consultancy_student.CheckedState.Parent = this.bt_take_consultancy_student;
            this.bt_take_consultancy_student.CustomImages.Parent = this.bt_take_consultancy_student;
            this.bt_take_consultancy_student.FillColor = System.Drawing.Color.Black;
            this.bt_take_consultancy_student.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_take_consultancy_student.ForeColor = System.Drawing.Color.White;
            this.bt_take_consultancy_student.HoverState.Parent = this.bt_take_consultancy_student;
            this.bt_take_consultancy_student.Location = new System.Drawing.Point(26, 289);
            this.bt_take_consultancy_student.Name = "bt_take_consultancy_student";
            this.bt_take_consultancy_student.ShadowDecoration.Parent = this.bt_take_consultancy_student;
            this.bt_take_consultancy_student.Size = new System.Drawing.Size(165, 45);
            this.bt_take_consultancy_student.TabIndex = 9;
            this.bt_take_consultancy_student.Text = "Take Consultancy";
            this.bt_take_consultancy_student.Click += new System.EventHandler(this.bt_take_consultancy_student_Click);
            // 
            // bt_student_forums
            // 
            this.bt_student_forums.BorderRadius = 20;
            this.bt_student_forums.CheckedState.Parent = this.bt_student_forums;
            this.bt_student_forums.CustomImages.Parent = this.bt_student_forums;
            this.bt_student_forums.FillColor = System.Drawing.Color.Black;
            this.bt_student_forums.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_student_forums.ForeColor = System.Drawing.Color.White;
            this.bt_student_forums.HoverState.Parent = this.bt_student_forums;
            this.bt_student_forums.Location = new System.Drawing.Point(26, 355);
            this.bt_student_forums.Name = "bt_student_forums";
            this.bt_student_forums.ShadowDecoration.Parent = this.bt_student_forums;
            this.bt_student_forums.Size = new System.Drawing.Size(165, 45);
            this.bt_student_forums.TabIndex = 8;
            this.bt_student_forums.Text = "Forums";
            this.bt_student_forums.Click += new System.EventHandler(this.bt_student_forums_Click);
            // 
            // bt_share_thesis_student
            // 
            this.bt_share_thesis_student.BorderRadius = 20;
            this.bt_share_thesis_student.CheckedState.Parent = this.bt_share_thesis_student;
            this.bt_share_thesis_student.CustomImages.Parent = this.bt_share_thesis_student;
            this.bt_share_thesis_student.FillColor = System.Drawing.Color.Black;
            this.bt_share_thesis_student.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_share_thesis_student.ForeColor = System.Drawing.Color.White;
            this.bt_share_thesis_student.HoverState.Parent = this.bt_share_thesis_student;
            this.bt_share_thesis_student.Location = new System.Drawing.Point(26, 222);
            this.bt_share_thesis_student.Name = "bt_share_thesis_student";
            this.bt_share_thesis_student.ShadowDecoration.Parent = this.bt_share_thesis_student;
            this.bt_share_thesis_student.Size = new System.Drawing.Size(165, 45);
            this.bt_share_thesis_student.TabIndex = 7;
            this.bt_share_thesis_student.Text = "Share Thesis";
            this.bt_share_thesis_student.Click += new System.EventHandler(this.bt_share_thesis_student_Click);
            // 
            // bt_exploreit_student
            // 
            this.bt_exploreit_student.BorderRadius = 20;
            this.bt_exploreit_student.CheckedState.Parent = this.bt_exploreit_student;
            this.bt_exploreit_student.CustomImages.Parent = this.bt_exploreit_student;
            this.bt_exploreit_student.FillColor = System.Drawing.Color.Black;
            this.bt_exploreit_student.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_exploreit_student.ForeColor = System.Drawing.Color.White;
            this.bt_exploreit_student.HoverState.Parent = this.bt_exploreit_student;
            this.bt_exploreit_student.Location = new System.Drawing.Point(26, 155);
            this.bt_exploreit_student.Name = "bt_exploreit_student";
            this.bt_exploreit_student.ShadowDecoration.Parent = this.bt_exploreit_student;
            this.bt_exploreit_student.Size = new System.Drawing.Size(165, 45);
            this.bt_exploreit_student.TabIndex = 6;
            this.bt_exploreit_student.Text = "Explore IT";
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.upload_research1);
            this.guna2Panel2.Controls.Add(this.stu_thesis_upload1);
            this.guna2Panel2.Controls.Add(this.uc_forum_view2);
            this.guna2Panel2.Controls.Add(this.uc_forum_view1);
            this.guna2Panel2.Location = new System.Drawing.Point(234, 12);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.ShadowDecoration.Parent = this.guna2Panel2;
            this.guna2Panel2.Size = new System.Drawing.Size(900, 581);
            this.guna2Panel2.TabIndex = 2;
            this.guna2Panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2Panel2_Paint);
            // 
            // upload_research1
            // 
            this.upload_research1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.upload_research1.Location = new System.Drawing.Point(0, 6);
            this.upload_research1.Name = "upload_research1";
            this.upload_research1.Size = new System.Drawing.Size(900, 572);
            this.upload_research1.TabIndex = 3;
            // 
            // stu_thesis_upload1
            // 
            this.stu_thesis_upload1.Location = new System.Drawing.Point(13, 0);
            this.stu_thesis_upload1.Name = "stu_thesis_upload1";
            this.stu_thesis_upload1.Size = new System.Drawing.Size(852, 584);
            this.stu_thesis_upload1.TabIndex = 2;
            // 
            // uc_forum_view2
            // 
            this.uc_forum_view2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uc_forum_view2.Location = new System.Drawing.Point(24, 12);
            this.uc_forum_view2.Name = "uc_forum_view2";
            this.uc_forum_view2.Size = new System.Drawing.Size(860, 538);
            this.uc_forum_view2.TabIndex = 1;
            // 
            // uc_forum_view1
            // 
            this.uc_forum_view1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.uc_forum_view1.Location = new System.Drawing.Point(13, 3);
            this.uc_forum_view1.Name = "uc_forum_view1";
            this.uc_forum_view1.Size = new System.Drawing.Size(860, 538);
            this.uc_forum_view1.TabIndex = 0;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this;
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.TargetControl = this;
            // 
            // guna2Elipse3
            // 
            this.guna2Elipse3.TargetControl = this;
            // 
            // student
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1177, 641);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.guna2Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "student";
            this.Text = "student";
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2ImageButton bt_student_image;
        private Guna.UI2.WinForms.Guna2Button bt_take_consultancy_student;
        private Guna.UI2.WinForms.Guna2Button bt_student_forums;
        private Guna.UI2.WinForms.Guna2Button bt_share_thesis_student;
        private Guna.UI2.WinForms.Guna2Button bt_exploreit_student;
        private Guna.UI2.WinForms.Guna2Button bt_logout_student;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private User_control.uc_forum_view uc_forum_view1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private User_control.uc_forum_view uc_forum_view2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private User_control.Stu_thesis_upload stu_thesis_upload1;
        private User_control.upload_research upload_research1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse3;
    }
}