﻿
namespace Explore_It_191096
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2ImageButton1 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.bt_create_account = new Guna.UI2.WinForms.Guna2Button();
            this.bt_admin = new Guna.UI2.WinForms.Guna2Button();
            this.bt_researcher = new Guna.UI2.WinForms.Guna2Button();
            this.bt_Student = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Panel2 = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2ImageButton2 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.uc_share_Research1 = new Explore_It_191096.User_control.uc_share_Research();
            this.uc_adminview1 = new Explore_It_191096.User_control.uc_adminview();
            this.uc_student_view1 = new Explore_It_191096.User_control.uc_student_view();
            this.uc_create_account1 = new Explore_It_191096.User_control.uc_create_account();
            this.uc_signup_student1 = new Explore_It_191096.User_control.uc_signup_student();
            this.uc_researcher_login1 = new Explore_It_191096.User_control.uc_researcher_login();
            this.uc_login_student1 = new Explore_It_191096.User_control.uc_login_student();
            this.uc_login_admin1 = new Explore_It_191096.User_control.uc_login_admin();
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse3 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse4 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse5 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Panel1.SuspendLayout();
            this.guna2Panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2Panel1
            // 
            this.guna2Panel1.Controls.Add(this.guna2ImageButton1);
            this.guna2Panel1.Controls.Add(this.bt_create_account);
            this.guna2Panel1.Controls.Add(this.bt_admin);
            this.guna2Panel1.Controls.Add(this.bt_researcher);
            this.guna2Panel1.Controls.Add(this.bt_Student);
            this.guna2Panel1.Location = new System.Drawing.Point(0, 0);
            this.guna2Panel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.guna2Panel1.Name = "guna2Panel1";
            this.guna2Panel1.ShadowDecoration.Parent = this.guna2Panel1;
            this.guna2Panel1.Size = new System.Drawing.Size(137, 360);
            this.guna2Panel1.TabIndex = 5;
            this.guna2Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2Panel1_Paint);
            // 
            // guna2ImageButton1
            // 
            this.guna2ImageButton1.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.CheckedState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.HoverState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton1.Image")));
            this.guna2ImageButton1.ImageRotate = 0F;
            this.guna2ImageButton1.ImageSize = new System.Drawing.Size(60, 60);
            this.guna2ImageButton1.Location = new System.Drawing.Point(33, 8);
            this.guna2ImageButton1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.guna2ImageButton1.Name = "guna2ImageButton1";
            this.guna2ImageButton1.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.PressedState.Parent = this.guna2ImageButton1;
            this.guna2ImageButton1.Size = new System.Drawing.Size(86, 68);
            this.guna2ImageButton1.TabIndex = 4;
            this.guna2ImageButton1.Click += new System.EventHandler(this.guna2ImageButton1_Click);
            // 
            // bt_create_account
            // 
            this.bt_create_account.BorderRadius = 20;
            this.bt_create_account.CheckedState.Parent = this.bt_create_account;
            this.bt_create_account.CustomImages.Parent = this.bt_create_account;
            this.bt_create_account.FillColor = System.Drawing.Color.Black;
            this.bt_create_account.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_create_account.ForeColor = System.Drawing.Color.White;
            this.bt_create_account.HoverState.Parent = this.bt_create_account;
            this.bt_create_account.Location = new System.Drawing.Point(18, 282);
            this.bt_create_account.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt_create_account.Name = "bt_create_account";
            this.bt_create_account.ShadowDecoration.Parent = this.bt_create_account;
            this.bt_create_account.Size = new System.Drawing.Size(110, 29);
            this.bt_create_account.TabIndex = 3;
            this.bt_create_account.Text = "Create Account";
            this.bt_create_account.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            this.bt_create_account.Click += new System.EventHandler(this.bt_create_account_Click_1);
            // 
            // bt_admin
            // 
            this.bt_admin.BorderRadius = 20;
            this.bt_admin.CheckedState.Parent = this.bt_admin;
            this.bt_admin.CustomImages.Parent = this.bt_admin;
            this.bt_admin.FillColor = System.Drawing.Color.Black;
            this.bt_admin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_admin.ForeColor = System.Drawing.Color.White;
            this.bt_admin.HoverState.Parent = this.bt_admin;
            this.bt_admin.Location = new System.Drawing.Point(18, 198);
            this.bt_admin.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt_admin.Name = "bt_admin";
            this.bt_admin.ShadowDecoration.Parent = this.bt_admin;
            this.bt_admin.Size = new System.Drawing.Size(110, 29);
            this.bt_admin.TabIndex = 2;
            this.bt_admin.Text = "Admin";
            this.bt_admin.Click += new System.EventHandler(this.bt_admin_Click);
            // 
            // bt_researcher
            // 
            this.bt_researcher.BorderRadius = 20;
            this.bt_researcher.CheckedState.Parent = this.bt_researcher;
            this.bt_researcher.CustomImages.Parent = this.bt_researcher;
            this.bt_researcher.FillColor = System.Drawing.Color.Black;
            this.bt_researcher.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_researcher.ForeColor = System.Drawing.Color.White;
            this.bt_researcher.HoverState.Parent = this.bt_researcher;
            this.bt_researcher.Location = new System.Drawing.Point(18, 154);
            this.bt_researcher.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt_researcher.Name = "bt_researcher";
            this.bt_researcher.ShadowDecoration.Parent = this.bt_researcher;
            this.bt_researcher.Size = new System.Drawing.Size(110, 29);
            this.bt_researcher.TabIndex = 1;
            this.bt_researcher.Text = "Researcher";
            this.bt_researcher.Click += new System.EventHandler(this.bt_researcher_Click);
            // 
            // bt_Student
            // 
            this.bt_Student.BorderRadius = 20;
            this.bt_Student.CheckedState.Parent = this.bt_Student;
            this.bt_Student.CustomImages.Parent = this.bt_Student;
            this.bt_Student.FillColor = System.Drawing.Color.Black;
            this.bt_Student.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bt_Student.ForeColor = System.Drawing.Color.White;
            this.bt_Student.HoverState.Parent = this.bt_Student;
            this.bt_Student.Location = new System.Drawing.Point(18, 108);
            this.bt_Student.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt_Student.Name = "bt_Student";
            this.bt_Student.ShadowDecoration.Parent = this.bt_Student;
            this.bt_Student.Size = new System.Drawing.Size(110, 29);
            this.bt_Student.TabIndex = 0;
            this.bt_Student.Text = "Student";
            this.bt_Student.Click += new System.EventHandler(this.bt_Student_Click);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this.guna2Panel2;
            // 
            // guna2Panel2
            // 
            this.guna2Panel2.Controls.Add(this.guna2ImageButton2);
            this.guna2Panel2.Controls.Add(this.uc_share_Research1);
            this.guna2Panel2.Controls.Add(this.uc_adminview1);
            this.guna2Panel2.Controls.Add(this.uc_student_view1);
            this.guna2Panel2.Controls.Add(this.uc_create_account1);
            this.guna2Panel2.Controls.Add(this.uc_signup_student1);
            this.guna2Panel2.Controls.Add(this.uc_researcher_login1);
            this.guna2Panel2.Controls.Add(this.uc_login_student1);
            this.guna2Panel2.Controls.Add(this.uc_login_admin1);
            this.guna2Panel2.Location = new System.Drawing.Point(151, 0);
            this.guna2Panel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.guna2Panel2.Name = "guna2Panel2";
            this.guna2Panel2.ShadowDecoration.Parent = this.guna2Panel2;
            this.guna2Panel2.Size = new System.Drawing.Size(453, 311);
            this.guna2Panel2.TabIndex = 6;
            // 
            // guna2ImageButton2
            // 
            this.guna2ImageButton2.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.CheckedState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.HoverState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton2.Image")));
            this.guna2ImageButton2.ImageRotate = 0F;
            this.guna2ImageButton2.ImageSize = new System.Drawing.Size(400, 400);
            this.guna2ImageButton2.Location = new System.Drawing.Point(-10, 8);
            this.guna2ImageButton2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.guna2ImageButton2.Name = "guna2ImageButton2";
            this.guna2ImageButton2.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton2.PressedState.Parent = this.guna2ImageButton2;
            this.guna2ImageButton2.Size = new System.Drawing.Size(472, 335);
            this.guna2ImageButton2.TabIndex = 8;
            // 
            // uc_share_Research1
            // 
            this.uc_share_Research1.Location = new System.Drawing.Point(484, 154);
            this.uc_share_Research1.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.uc_share_Research1.Name = "uc_share_Research1";
            this.uc_share_Research1.Size = new System.Drawing.Size(136, 220);
            this.uc_share_Research1.TabIndex = 7;
            this.uc_share_Research1.Load += new System.EventHandler(this.uc_share_Research1_Load);
            // 
            // uc_adminview1
            // 
            this.uc_adminview1.Location = new System.Drawing.Point(-28, 0);
            this.uc_adminview1.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.uc_adminview1.Name = "uc_adminview1";
            this.uc_adminview1.Size = new System.Drawing.Size(577, 380);
            this.uc_adminview1.TabIndex = 6;
            // 
            // uc_student_view1
            // 
            this.uc_student_view1.Location = new System.Drawing.Point(-41, 2);
            this.uc_student_view1.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.uc_student_view1.Name = "uc_student_view1";
            this.uc_student_view1.Size = new System.Drawing.Size(661, 435);
            this.uc_student_view1.TabIndex = 5;
            this.uc_student_view1.Load += new System.EventHandler(this.uc_student_view1_Load);
            // 
            // uc_create_account1
            // 
            this.uc_create_account1.Location = new System.Drawing.Point(-19, 0);
            this.uc_create_account1.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.uc_create_account1.Name = "uc_create_account1";
            this.uc_create_account1.Size = new System.Drawing.Size(607, 414);
            this.uc_create_account1.TabIndex = 4;
            // 
            // uc_signup_student1
            // 
            this.uc_signup_student1.Location = new System.Drawing.Point(398, 272);
            this.uc_signup_student1.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.uc_signup_student1.Name = "uc_signup_student1";
            this.uc_signup_student1.Size = new System.Drawing.Size(63, 46);
            this.uc_signup_student1.TabIndex = 3;
            // 
            // uc_researcher_login1
            // 
            this.uc_researcher_login1.Location = new System.Drawing.Point(0, 0);
            this.uc_researcher_login1.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.uc_researcher_login1.Name = "uc_researcher_login1";
            this.uc_researcher_login1.Size = new System.Drawing.Size(461, 320);
            this.uc_researcher_login1.TabIndex = 2;
            // 
            // uc_login_student1
            // 
            this.uc_login_student1.Location = new System.Drawing.Point(0, 0);
            this.uc_login_student1.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.uc_login_student1.Name = "uc_login_student1";
            this.uc_login_student1.Size = new System.Drawing.Size(461, 320);
            this.uc_login_student1.TabIndex = 1;
            // 
            // uc_login_admin1
            // 
            this.uc_login_admin1.Location = new System.Drawing.Point(0, 0);
            this.uc_login_admin1.Margin = new System.Windows.Forms.Padding(1, 1, 1, 1);
            this.uc_login_admin1.Name = "uc_login_admin1";
            this.uc_login_admin1.Size = new System.Drawing.Size(461, 320);
            this.uc_login_admin1.TabIndex = 0;
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.TargetControl = this.guna2Panel2;
            // 
            // guna2Elipse3
            // 
            this.guna2Elipse3.TargetControl = this.guna2Panel2;
            // 
            // guna2Elipse4
            // 
            this.guna2Elipse4.TargetControl = this;
            // 
            // guna2Elipse5
            // 
            this.guna2Elipse5.TargetControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(791, 438);
            this.Controls.Add(this.guna2Panel2);
            this.Controls.Add(this.guna2Panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.guna2Panel1.ResumeLayout(false);
            this.guna2Panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2Button bt_admin;
        private Guna.UI2.WinForms.Guna2Button bt_researcher;
        private Guna.UI2.WinForms.Guna2Button bt_Student;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel2;
        private Guna.UI2.WinForms.Guna2Button bt_create_account;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse3;
        private User_control.uc_researcher_login uc_researcher_login1;
        private User_control.uc_login_student uc_login_student1;
        private User_control.uc_login_admin uc_login_admin1;
        private User_control.uc_signup_student uc_signup_student1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse4;
        //private User_control.uc_ uc_1;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse5;
        private User_control.uc_create_account uc_create_account1;
        private User_control.uc_student_view uc_student_view1;
        private User_control.uc_adminview uc_adminview1;
        private User_control.uc_share_Research uc_share_Research1;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton2;
    }
}

