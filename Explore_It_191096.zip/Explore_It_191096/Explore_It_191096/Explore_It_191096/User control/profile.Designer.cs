﻿
namespace Explore_It_191096.User_control
{
    partial class profile
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.name_textbox_profile = new Guna.UI2.WinForms.Guna2TextBox();
            this.username_tectbox_profile = new Guna.UI2.WinForms.Guna2TextBox();
            this.password_textbox_profile = new Guna.UI2.WinForms.Guna2TextBox();
            this.save_button_profiel = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.admin_id = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.SuspendLayout();
            // 
            // name_textbox_profile
            // 
            this.name_textbox_profile.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.name_textbox_profile.DefaultText = "";
            this.name_textbox_profile.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.name_textbox_profile.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.name_textbox_profile.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.name_textbox_profile.DisabledState.Parent = this.name_textbox_profile;
            this.name_textbox_profile.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.name_textbox_profile.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.name_textbox_profile.FocusedState.Parent = this.name_textbox_profile;
            this.name_textbox_profile.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.name_textbox_profile.HoverState.Parent = this.name_textbox_profile;
            this.name_textbox_profile.Location = new System.Drawing.Point(285, 146);
            this.name_textbox_profile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.name_textbox_profile.Name = "name_textbox_profile";
            this.name_textbox_profile.PasswordChar = '\0';
            this.name_textbox_profile.PlaceholderText = "Enter name";
            this.name_textbox_profile.SelectedText = "";
            this.name_textbox_profile.ShadowDecoration.Parent = this.name_textbox_profile;
            this.name_textbox_profile.Size = new System.Drawing.Size(300, 55);
            this.name_textbox_profile.TabIndex = 0;
            // 
            // username_tectbox_profile
            // 
            this.username_tectbox_profile.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.username_tectbox_profile.DefaultText = "";
            this.username_tectbox_profile.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.username_tectbox_profile.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.username_tectbox_profile.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.username_tectbox_profile.DisabledState.Parent = this.username_tectbox_profile;
            this.username_tectbox_profile.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.username_tectbox_profile.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.username_tectbox_profile.FocusedState.Parent = this.username_tectbox_profile;
            this.username_tectbox_profile.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.username_tectbox_profile.HoverState.Parent = this.username_tectbox_profile;
            this.username_tectbox_profile.Location = new System.Drawing.Point(285, 211);
            this.username_tectbox_profile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.username_tectbox_profile.Name = "username_tectbox_profile";
            this.username_tectbox_profile.PasswordChar = '\0';
            this.username_tectbox_profile.PlaceholderText = "Enter username";
            this.username_tectbox_profile.SelectedText = "";
            this.username_tectbox_profile.ShadowDecoration.Parent = this.username_tectbox_profile;
            this.username_tectbox_profile.Size = new System.Drawing.Size(300, 55);
            this.username_tectbox_profile.TabIndex = 1;
            // 
            // password_textbox_profile
            // 
            this.password_textbox_profile.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.password_textbox_profile.DefaultText = "";
            this.password_textbox_profile.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.password_textbox_profile.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.password_textbox_profile.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.password_textbox_profile.DisabledState.Parent = this.password_textbox_profile;
            this.password_textbox_profile.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.password_textbox_profile.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.password_textbox_profile.FocusedState.Parent = this.password_textbox_profile;
            this.password_textbox_profile.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.password_textbox_profile.HoverState.Parent = this.password_textbox_profile;
            this.password_textbox_profile.Location = new System.Drawing.Point(285, 276);
            this.password_textbox_profile.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.password_textbox_profile.Name = "password_textbox_profile";
            this.password_textbox_profile.PasswordChar = '\0';
            this.password_textbox_profile.PlaceholderText = "Enter Password";
            this.password_textbox_profile.SelectedText = "";
            this.password_textbox_profile.ShadowDecoration.Parent = this.password_textbox_profile;
            this.password_textbox_profile.Size = new System.Drawing.Size(300, 55);
            this.password_textbox_profile.TabIndex = 2;
            // 
            // save_button_profiel
            // 
            this.save_button_profiel.CheckedState.Parent = this.save_button_profiel;
            this.save_button_profiel.CustomImages.Parent = this.save_button_profiel;
            this.save_button_profiel.FillColor = System.Drawing.Color.Magenta;
            this.save_button_profiel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.save_button_profiel.ForeColor = System.Drawing.Color.White;
            this.save_button_profiel.HoverState.Parent = this.save_button_profiel;
            this.save_button_profiel.Location = new System.Drawing.Point(342, 371);
            this.save_button_profiel.Name = "save_button_profiel";
            this.save_button_profiel.ShadowDecoration.Parent = this.save_button_profiel;
            this.save_button_profiel.Size = new System.Drawing.Size(180, 45);
            this.save_button_profiel.TabIndex = 3;
            this.save_button_profiel.Text = "SAVE";
            this.save_button_profiel.Click += new System.EventHandler(this.save_button_profiel_Click);
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(307, 50);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(244, 30);
            this.guna2HtmlLabel1.TabIndex = 4;
            this.guna2HtmlLabel1.Text = "Admin Profile details";
            // 
            // admin_id
            // 
            this.admin_id.BackColor = System.Drawing.Color.Transparent;
            this.admin_id.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.admin_id.Location = new System.Drawing.Point(285, 107);
            this.admin_id.Name = "admin_id";
            this.admin_id.Size = new System.Drawing.Size(79, 31);
            this.admin_id.TabIndex = 16;
            this.admin_id.Text = "Identity";
            // 
            // profile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.admin_id);
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.save_button_profiel);
            this.Controls.Add(this.password_textbox_profile);
            this.Controls.Add(this.username_tectbox_profile);
            this.Controls.Add(this.name_textbox_profile);
            this.Name = "profile";
            this.Size = new System.Drawing.Size(782, 551);
            this.Load += new System.EventHandler(this.profile_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox name_textbox_profile;
        private Guna.UI2.WinForms.Guna2TextBox username_tectbox_profile;
        private Guna.UI2.WinForms.Guna2TextBox password_textbox_profile;
        private Guna.UI2.WinForms.Guna2Button save_button_profiel;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel admin_id;
    }
}
