﻿
namespace Explore_It_191096.User_control
{
    partial class uc_create_account
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Entername_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Enterusername_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.Enter_password_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.signup_button = new Guna.UI2.WinForms.Guna2Button();
            this.combobox_textbox = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.Signin_institute_textbox = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.SuspendLayout();
            // 
            // Entername_textbox
            // 
            this.Entername_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Entername_textbox.DefaultText = "";
            this.Entername_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Entername_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Entername_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Entername_textbox.DisabledState.Parent = this.Entername_textbox;
            this.Entername_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Entername_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Entername_textbox.FocusedState.Parent = this.Entername_textbox;
            this.Entername_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Entername_textbox.HoverState.Parent = this.Entername_textbox;
            this.Entername_textbox.Location = new System.Drawing.Point(274, 96);
            this.Entername_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Entername_textbox.Name = "Entername_textbox";
            this.Entername_textbox.PasswordChar = '\0';
            this.Entername_textbox.PlaceholderText = "Enter Name";
            this.Entername_textbox.SelectedText = "";
            this.Entername_textbox.ShadowDecoration.Parent = this.Entername_textbox;
            this.Entername_textbox.Size = new System.Drawing.Size(300, 55);
            this.Entername_textbox.TabIndex = 0;
            this.Entername_textbox.TextChanged += new System.EventHandler(this.Entername_textbox_TextChanged);
            // 
            // Enterusername_textbox
            // 
            this.Enterusername_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Enterusername_textbox.DefaultText = "";
            this.Enterusername_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Enterusername_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Enterusername_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Enterusername_textbox.DisabledState.Parent = this.Enterusername_textbox;
            this.Enterusername_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Enterusername_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Enterusername_textbox.FocusedState.Parent = this.Enterusername_textbox;
            this.Enterusername_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Enterusername_textbox.HoverState.Parent = this.Enterusername_textbox;
            this.Enterusername_textbox.Location = new System.Drawing.Point(274, 161);
            this.Enterusername_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Enterusername_textbox.Name = "Enterusername_textbox";
            this.Enterusername_textbox.PasswordChar = '\0';
            this.Enterusername_textbox.PlaceholderText = "Enter User name]";
            this.Enterusername_textbox.SelectedText = "";
            this.Enterusername_textbox.ShadowDecoration.Parent = this.Enterusername_textbox;
            this.Enterusername_textbox.Size = new System.Drawing.Size(300, 55);
            this.Enterusername_textbox.TabIndex = 1;
            this.Enterusername_textbox.TextChanged += new System.EventHandler(this.Enterusername_textbox_TextChanged);
            // 
            // Enter_password_textbox
            // 
            this.Enter_password_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Enter_password_textbox.DefaultText = "";
            this.Enter_password_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Enter_password_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Enter_password_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Enter_password_textbox.DisabledState.Parent = this.Enter_password_textbox;
            this.Enter_password_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Enter_password_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Enter_password_textbox.FocusedState.Parent = this.Enter_password_textbox;
            this.Enter_password_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Enter_password_textbox.HoverState.Parent = this.Enter_password_textbox;
            this.Enter_password_textbox.Location = new System.Drawing.Point(274, 226);
            this.Enter_password_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Enter_password_textbox.Name = "Enter_password_textbox";
            this.Enter_password_textbox.PasswordChar = '\0';
            this.Enter_password_textbox.PlaceholderText = "Passward";
            this.Enter_password_textbox.SelectedText = "";
            this.Enter_password_textbox.ShadowDecoration.Parent = this.Enter_password_textbox;
            this.Enter_password_textbox.Size = new System.Drawing.Size(300, 55);
            this.Enter_password_textbox.TabIndex = 2;
            this.Enter_password_textbox.TextChanged += new System.EventHandler(this.Enter_password_textbox_TextChanged);
            // 
            // signup_button
            // 
            this.signup_button.CheckedState.Parent = this.signup_button;
            this.signup_button.CustomImages.Parent = this.signup_button;
            this.signup_button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.signup_button.ForeColor = System.Drawing.Color.White;
            this.signup_button.HoverState.Parent = this.signup_button;
            this.signup_button.Location = new System.Drawing.Point(320, 440);
            this.signup_button.Name = "signup_button";
            this.signup_button.ShadowDecoration.Parent = this.signup_button;
            this.signup_button.Size = new System.Drawing.Size(180, 45);
            this.signup_button.TabIndex = 3;
            this.signup_button.Text = "SIGN IN";
            this.signup_button.Click += new System.EventHandler(this.signup_button_Click);
            // 
            // combobox_textbox
            // 
            this.combobox_textbox.BackColor = System.Drawing.Color.Transparent;
            this.combobox_textbox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.combobox_textbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combobox_textbox.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.combobox_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.combobox_textbox.FocusedState.Parent = this.combobox_textbox;
            this.combobox_textbox.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.combobox_textbox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.combobox_textbox.HoverState.Parent = this.combobox_textbox;
            this.combobox_textbox.ItemHeight = 30;
            this.combobox_textbox.Items.AddRange(new object[] {
            "Student",
            "Researcher",
            "Admin"});
            this.combobox_textbox.ItemsAppearance.Parent = this.combobox_textbox;
            this.combobox_textbox.Location = new System.Drawing.Point(274, 354);
            this.combobox_textbox.Name = "combobox_textbox";
            this.combobox_textbox.ShadowDecoration.Parent = this.combobox_textbox;
            this.combobox_textbox.Size = new System.Drawing.Size(300, 36);
            this.combobox_textbox.TabIndex = 4;
            this.combobox_textbox.SelectedIndexChanged += new System.EventHandler(this.combobox_textbox_SelectedIndexChanged);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this;
            // 
            // Signin_institute_textbox
            // 
            this.Signin_institute_textbox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Signin_institute_textbox.DefaultText = "";
            this.Signin_institute_textbox.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Signin_institute_textbox.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Signin_institute_textbox.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Signin_institute_textbox.DisabledState.Parent = this.Signin_institute_textbox;
            this.Signin_institute_textbox.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Signin_institute_textbox.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Signin_institute_textbox.FocusedState.Parent = this.Signin_institute_textbox;
            this.Signin_institute_textbox.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Signin_institute_textbox.HoverState.Parent = this.Signin_institute_textbox;
            this.Signin_institute_textbox.Location = new System.Drawing.Point(274, 291);
            this.Signin_institute_textbox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Signin_institute_textbox.Name = "Signin_institute_textbox";
            this.Signin_institute_textbox.PasswordChar = '\0';
            this.Signin_institute_textbox.PlaceholderText = "Institute";
            this.Signin_institute_textbox.SelectedText = "";
            this.Signin_institute_textbox.ShadowDecoration.Parent = this.Signin_institute_textbox;
            this.Signin_institute_textbox.Size = new System.Drawing.Size(300, 55);
            this.Signin_institute_textbox.TabIndex = 5;
            this.Signin_institute_textbox.TextChanged += new System.EventHandler(this.Signin_institute_textbox_TextChanged);
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(346, 56);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(166, 32);
            this.guna2HtmlLabel1.TabIndex = 6;
            this.guna2HtmlLabel1.Text = "Create Account";
            this.guna2HtmlLabel1.Click += new System.EventHandler(this.guna2HtmlLabel1_Click);
            // 
            // uc_create_account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.Signin_institute_textbox);
            this.Controls.Add(this.combobox_textbox);
            this.Controls.Add(this.signup_button);
            this.Controls.Add(this.Enter_password_textbox);
            this.Controls.Add(this.Enterusername_textbox);
            this.Controls.Add(this.Entername_textbox);
            this.Name = "uc_create_account";
            this.Size = new System.Drawing.Size(854, 515);
            this.Load += new System.EventHandler(this.uc_create_account_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox Entername_textbox;
        private Guna.UI2.WinForms.Guna2TextBox Enterusername_textbox;
        private Guna.UI2.WinForms.Guna2TextBox Enter_password_textbox;
        private Guna.UI2.WinForms.Guna2Button signup_button;
        private Guna.UI2.WinForms.Guna2ComboBox combobox_textbox;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2TextBox Signin_institute_textbox;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
    }
}
