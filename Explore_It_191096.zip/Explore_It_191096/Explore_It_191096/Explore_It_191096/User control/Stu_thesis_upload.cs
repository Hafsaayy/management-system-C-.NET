﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096.User_control
{
    public partial class Stu_thesis_upload : UserControl
    {
        public Stu_thesis_upload()
        {
            InitializeComponent();
        }

        private void Upload_thesis_button_Click(object sender, EventArgs e)
        {

        }

        private void thesis_paper_heading_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void thesis_discritption_textbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
