﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096.User_control
{
    public partial class uc_login_student : UserControl
    {
        public uc_login_student()
        {
            InitializeComponent();
        }

        private void bt_student_login_Click(object sender, EventArgs e)
        {
            database Database = new database();
            if (Student_username_textbox.Text != "" && stu_password_textbox.Text != "")
            {

                String username = Student_username_textbox.Text;
                String password = Student_password_textbox.Text;
                String Query = "Select * from Students where Stu_username = '" + username + "' and " +
                    "Stu_password = '" + password + "'";

                DataSet dt = Database.Get_Data(Query);
                if (dt.Tables[0].Rows.Count != 0)
                {
                    student s = new student();
                    s.Show();

                }
                else
                {
                    MessageBox.Show("Invalid Username or Password..");
                }
            }
            else
            {

            }
            Student_username_textbox.Clear();

            stu_password_textbox.Clear();
        }

        private void guna2HtmlLabel2_Click(object sender, EventArgs e)
        {

        }

        private void Student_password_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Student_username_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void bt_stu_login_Click(object sender, EventArgs e)
        {

        }

        private void stu_password_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Stu_username_textbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
