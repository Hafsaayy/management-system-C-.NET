﻿
namespace Explore_It_191096.User_control
{
    partial class uc_
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Enter_name_ca = new Guna.UI2.WinForms.Guna2TextBox();
            this.Enterusername_ca = new Guna.UI2.WinForms.Guna2TextBox();
            this.enter_password_cs = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2ComboBox1 = new Guna.UI2.WinForms.Guna2ComboBox();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.SuspendLayout();
            // 
            // Enter_name_ca
            // 
            this.Enter_name_ca.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Enter_name_ca.DefaultText = "";
            this.Enter_name_ca.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Enter_name_ca.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Enter_name_ca.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Enter_name_ca.DisabledState.Parent = this.Enter_name_ca;
            this.Enter_name_ca.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Enter_name_ca.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Enter_name_ca.FocusedState.Parent = this.Enter_name_ca;
            this.Enter_name_ca.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Enter_name_ca.HoverState.Parent = this.Enter_name_ca;
            this.Enter_name_ca.Location = new System.Drawing.Point(255, 146);
            this.Enter_name_ca.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Enter_name_ca.Name = "Enter_name_ca";
            this.Enter_name_ca.PasswordChar = '\0';
            this.Enter_name_ca.PlaceholderText = "Enter Name";
            this.Enter_name_ca.SelectedText = "";
            this.Enter_name_ca.ShadowDecoration.Parent = this.Enter_name_ca;
            this.Enter_name_ca.Size = new System.Drawing.Size(300, 55);
            this.Enter_name_ca.TabIndex = 0;
            // 
            // Enterusername_ca
            // 
            this.Enterusername_ca.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Enterusername_ca.DefaultText = "";
            this.Enterusername_ca.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.Enterusername_ca.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.Enterusername_ca.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Enterusername_ca.DisabledState.Parent = this.Enterusername_ca;
            this.Enterusername_ca.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.Enterusername_ca.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Enterusername_ca.FocusedState.Parent = this.Enterusername_ca;
            this.Enterusername_ca.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Enterusername_ca.HoverState.Parent = this.Enterusername_ca;
            this.Enterusername_ca.Location = new System.Drawing.Point(255, 211);
            this.Enterusername_ca.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Enterusername_ca.Name = "Enterusername_ca";
            this.Enterusername_ca.PasswordChar = '\0';
            this.Enterusername_ca.PlaceholderText = "Enter Username";
            this.Enterusername_ca.SelectedText = "";
            this.Enterusername_ca.ShadowDecoration.Parent = this.Enterusername_ca;
            this.Enterusername_ca.Size = new System.Drawing.Size(300, 55);
            this.Enterusername_ca.TabIndex = 1;
            // 
            // enter_password_cs
            // 
            this.enter_password_cs.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.enter_password_cs.DefaultText = "";
            this.enter_password_cs.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.enter_password_cs.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.enter_password_cs.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.enter_password_cs.DisabledState.Parent = this.enter_password_cs;
            this.enter_password_cs.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.enter_password_cs.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.enter_password_cs.FocusedState.Parent = this.enter_password_cs;
            this.enter_password_cs.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.enter_password_cs.HoverState.Parent = this.enter_password_cs;
            this.enter_password_cs.Location = new System.Drawing.Point(255, 276);
            this.enter_password_cs.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.enter_password_cs.Name = "enter_password_cs";
            this.enter_password_cs.PasswordChar = '\0';
            this.enter_password_cs.PlaceholderText = "Enter Password";
            this.enter_password_cs.SelectedText = "";
            this.enter_password_cs.ShadowDecoration.Parent = this.enter_password_cs;
            this.enter_password_cs.Size = new System.Drawing.Size(300, 55);
            this.enter_password_cs.TabIndex = 2;
            // 
            // guna2ComboBox1
            // 
            this.guna2ComboBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2ComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.guna2ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.guna2ComboBox1.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2ComboBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2ComboBox1.FocusedState.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.guna2ComboBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(88)))), ((int)(((byte)(112)))));
            this.guna2ComboBox1.HoverState.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.ItemHeight = 30;
            this.guna2ComboBox1.Items.AddRange(new object[] {
            "Student",
            "Researcher",
            "Admin"});
            this.guna2ComboBox1.ItemsAppearance.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.Location = new System.Drawing.Point(255, 339);
            this.guna2ComboBox1.Name = "guna2ComboBox1";
            this.guna2ComboBox1.ShadowDecoration.Parent = this.guna2ComboBox1;
            this.guna2ComboBox1.Size = new System.Drawing.Size(300, 36);
            this.guna2ComboBox1.TabIndex = 3;
            // 
            // guna2Button1
            // 
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(320, 416);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(180, 45);
            this.guna2Button1.TabIndex = 4;
            this.guna2Button1.Text = "Sign up";
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(310, 97);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(190, 22);
            this.guna2HtmlLabel1.TabIndex = 5;
            this.guna2HtmlLabel1.Text = "CREATE NEW ACCOUNT";
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.TargetControl = this;
            // 
            // uc_
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.guna2HtmlLabel1);
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.guna2ComboBox1);
            this.Controls.Add(this.enter_password_cs);
            this.Controls.Add(this.Enterusername_ca);
            this.Controls.Add(this.Enter_name_ca);
            this.Name = "uc_";
            this.Size = new System.Drawing.Size(807, 511);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox Enter_name_ca;
        private Guna.UI2.WinForms.Guna2TextBox Enterusername_ca;
        private Guna.UI2.WinForms.Guna2TextBox enter_password_cs;
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
    }
}
