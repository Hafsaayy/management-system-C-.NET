﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096.User_control
{
    public partial class uc_researcher_login : UserControl
    {
        public uc_researcher_login()
        {
            InitializeComponent();
        }

        private void bt_researcher_login_Click(object sender, EventArgs e)
        {

            database Database = new database();
            if (Researcher_username_textbox.Text != "" && Researcher_password_textbox.Text != "")
            {

                String username = Researcher_username_textbox.Text;
                String password = Researcher_password_textbox.Text;
                String Query = "Select * from Researcher where Res_username = '" + username + "' and " +
                    "Res_password = '" + password + "'";

                DataSet dt = Database.Get_Data(Query);
                if (dt.Tables[0].Rows.Count != 0)
                {
                    Researcher s = new Researcher();
                    s.Show();

                }
                else
                {
                    MessageBox.Show("Invalid Username or Password..");
                }
            }
            else
            {

            }
            Researcher_username_textbox.Clear();

            Researcher_password_textbox.Clear();
        }

        private void guna2HtmlLabel1_Click(object sender, EventArgs e)
        {

        }

        private void Researcher_password_textbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Researcher_username_textbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
