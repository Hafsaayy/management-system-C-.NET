﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Explore_It_191096
{
    public partial class student : Form
    {
        public student()
        {
            InitializeComponent();
        }

        private void bt_logout_student_Click(object sender, EventArgs e)
        {
            Form1 f2 = new Form1();
            f2.Visible = true;
        }

        private void guna2Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bt_take_consultancy_student_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Contact on this number for the CONSULTANCY +92 3069275082");
        }

        private void bt_student_forums_Click(object sender, EventArgs e)
        {
            uc_forum_view1.Visible = true;
            uc_forum_view1.BringToFront();
            
        }

        private void bt_share_thesis_student_Click(object sender, EventArgs e)
        {
            upload_research1.Visible = true;
            upload_research1.BringToFront();
        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
